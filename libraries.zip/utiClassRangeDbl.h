/*   ../libmy/utiClassRangeDbl.h                                              */
/*  Mennessier Gerard                   940810                                */
/*  Last Revised              M.G.      970421                                */

#ifndef  DEF_UTICLASSRANGEDBL_H
#define  DEF_UTICLASSRANGEDBL_H

#include  <stddef.h>

void      ranindDbl(double *xp,int *indp,size_t nz);
int       classDbl(int *indexp,double x,double *xp,size_t nx);

#endif
/******************************************************************************/
/******************************************************************************/
