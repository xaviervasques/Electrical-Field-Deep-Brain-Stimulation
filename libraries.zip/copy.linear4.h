/*  URMAE/numerical/linear4/copy.linear4.h                                    */
/*  Mennessier Gerard                 20010527                                */
/*  Last Revised : G.M.               20010527                                */

#ifndef  DEF_COPY_LINEAR4_H
#define  DEF_COPY_LINEAR4_H

#include  <stddef.h>

#include  "cylPot.linear4.h"
#include  "eltrdPot.linear4.h"
#include  "pot.linear4.h"

void     copyLinearCyl(double *weightp, int weightx, double dV,
                                                 gmCylPot *cylPp, gmCylPot *cylPbsp);
void     copyLinearEltrd(double *weightp, int weightx, double dV,
                                         gmEltrdPot *eltrdPp, gmEltrdPot *eltrdPbsp);
void     copyLinearPot(double *weightp, int weightx, double dV,
                                                             gmPot *Vp, gmPot *Vbsp);

#endif
/******************************************************************************/
/******************************************************************************/
