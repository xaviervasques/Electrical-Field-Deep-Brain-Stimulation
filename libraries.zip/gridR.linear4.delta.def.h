/*  .../orientHaut/linear4.Common.V1/gridR.linear4.delta.def.h                */
/*  Mennessier Gerard                 20020404                                */
/*  Last Revised : G.M.               20020404                                */

#ifndef  DEF_GRIDR_LINEAR4_DELTA_DEF_H
#define  DEF_GRIDR_LINEAR4_DELTA_DEF_H

#define   MYDELTARN_  9

#endif
/******************************************************************************/
/******************************************************************************/
