/*  ../libmy/utiImage0D.h                                                     */
/*  Mennessier Gerard                   20031007                              */
/*  Last revised M.G.                   20031010                              */

#ifndef  DEF_UTIIMAGE0D_H
#define  DEF_UTIIMAGE0D_H

#include  <stddef.h>
#include  "utistdIO.h"

/******************************************************************************/
                          /** bytesPerPixel = effective number of bytes per pixel **/
                                 /** (8,12,16,24,... planes => 1,2,2,4,... bytes) **/
                                    /** BUT there may be padding with full bytes  **/
           /** for instance depth 24 may be padded to 4 bytes, though 3 is enough **/

typedef struct  utiImage0D
{ int     byteOrder;                                               /** byte order **/
  int     depth;
  int     bytesPerPixel;                  /** effective number of bytes per pixel **/
} utiImage0D, *utiImage0Dp;

/******************************************************************************/

void      utiImage0DSet(utiImage0D *ep, int byteOrder, int depth, int bytesPerPixel);
void      utiImage0DPrint(FILE *streamp, utiImage0D *ep);
void      utiImage0DCpy (utiImage0D *efp, utiImage0D ei);
void      utiImage0DCpyp(utiImage0D *efp, utiImage0D *eip);
short     utiImage0DCompatible(utiImage0D *e0p, utiImage0D *e1p);

#endif
/******************************************************************************/
/******************************************************************************/
