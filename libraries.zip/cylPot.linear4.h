/*  URMAE/numerical/linear4/cylPot.linear4.h                                  */
/*  Mennessier Gerard                 20010522                                */
/*  Last Revised : G.M.               20010523                                */

#ifndef  DEF_CYLPOT_LINEAR4_H
#define  DEF_CYLPOT_LINEAR4_H

#include  <stddef.h>
#include  "utistdIO.h"

typedef struct gmCylPot
{ int       cylcond;    /** -1 full insulator, 0 neck conductor, 1 full conductor **/
  int       neckMod;           /** 0 fixed, 1 variable (relevant if cylcond >= 0) **/
  double    infiniV;                         /** neck or boundary potential value **/
  double    neckI;                                             /** neck intensity **/
} gmCylPot, *gmCylPotp;

void      gmCylPotZero(gmCylPot *p);
void      gmCylPotPrint(FILE *bufOut, gmCylPot *p);
void      gmCylPotWrite(FILE *bufOut, gmCylPot *p);
void      gmCylPotRead(FILE *bufOut, gmCylPot *p);
void      gmCylPotSetMode(gmCylPot *p, int cylcond, int neckmode);
void      gmCylPotSetV(gmCylPot *p, double neckv);
void      gmCylPotSetI(gmCylPot *p, double necki);
void      gmCylPotCpy(gmCylPot *pf, gmCylPot *pi);

#endif
/******************************************************************************/
/******************************************************************************/
