Ligne de Champs; Volume Intersection; Volume Inter 1/2 post�rieur; Volume Inter 1/2 ant�rieur; 
 
 0.200000, 7.222198, 7.222198, 0.000000
