/*  URMAE/orientHaut/linear4.GL.V2/gl.linear4.03.globalloc.h                  */
/*  Mennessier Gerard                 20010810                                */
/*  Last Revised : G.M.               20030513                                */

#ifndef  DEF_GL_LINEAR4_03_GLOBALLOC_H
#define  DEF_GL_LINEAR4_03_GLOBALLOC_H

#include  <GL/glut.h>
#include  "utiVecChr.h"

GLfloat   win03ew, win03eh,
          win030ew, win030eh, win031ew, win031eh, win032ew, win032eh, 
                                                                  win033ew, win033eh;

GLfloat   rs03w  = 1.0, rs03h  = 0.20;
GLfloat   rs030w = 0.44, rs031w = 0.44, rs032w = 0.02, rs033w = 0.1;
GLfloat   rs030h = 0.7,  rs031h = 0.7,  rs032h = 0.7,  rs033h = 0.7;
GLfloat   p03w = 0.0,   p03h = 0.60;
GLfloat   p030w = 0.0,  p031w = 0.44, p032w = 0.88, p033w = 0.9;
GLfloat   p030h = 0.3,  p031h = 0.3,  p032h = 0.3,  p033h = 0.3;

chrVec    PallidusFileNameV = {0,0,NULL};

chrVec    PSfileNameBaseV = {0,0,NULL};
chrVec    PSfileNameEV    = {0,0,NULL};
chrVec    PSfileNameSTV   = {0,0,NULL};

char      frameEp[] = "electrode frame",  frameSp[] = "scanner frame";
int       framei = 0;

#endif
/******************************************************************************/
/******************************************************************************/
