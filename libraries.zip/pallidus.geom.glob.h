/*  URMAE/orientHaut/linear4.GL.V1/pallidus.geom.glob.h                       */
/*  Mennessier Gerard                 20010703                                */
/*  Last Revised : G.M.               20020410                                */

#ifndef  DEF_PALLIDUS_GEOM_GLOB_H
#define  DEF_PALLIDUS_GEOM_GLOB_H

#include  "utiVecDbl.h"
#include  "utiVecInt.h"

extern    intVec    eltrdPinIndVi;                   /** pin indices **/
extern    dblVec    eltrdSPosVd;    /** ScannerFrame electrode coord **/

                              /** READ DATA  **/
                             /** ScannerFrame pallidus coord **/
                             /** number of pallidus boundary points in each plane **/
extern    intVec    pallidusNptPlaneDataVi;
extern    intVec    pallidusPosDataVi;
                                                             /** AFTER plane SORT **/
extern    intVec    pallidusNptPlaneVi;
extern    dblVec    pallidusSPosVd;
                                                             /** AFTER angle SORT **/
extern    dblVec    pallidusSsortedPosVd;

extern    double    eltrdSOrip[3];       /** ScannerFrame: electrode center coord **/
extern    double    eltrdSVecp[3];     /** ScannerFrame: electrode unit direction **/
extern    double    ctheta, stheta, thetaRad, thetaDeg, cphi, sphi, phiRad, phiDeg;
                                                       /** rotation matrix S->E **/
extern    double    S2E0p[3], S2E1p[3], S2E2p[3];
extern    double   *S2Epp[3];
                                                        /** rotation matrix E->ST **/
extern    double    E2ST0p[3], E2ST1p[3], E2ST2p[3];
extern    double   *E2STpp[3];

                              /** SCANNER (TRANSLATED) FRAME **/
                                         /** ScannerFrame pallidus boundary coord **/
                                 /** reconstructed from data. May have more points**/
extern    dblVec    pallidusSTBoundVd;

            /** ScannerFrame boundary after rotation around Oz scanner translated **/
extern    dblVec    pallidusSTBoundRotatedVd;

                              /** ELECTRODE FRAME **/
                                       /** ElectrodeFrame pallidus boundary coord **/
extern    dblVec    pallidusEBoundVd;
                                                 
   /** ElectrodeFrame boundary coord after final psi rotation around Oz electrode **/
extern    dblVec    pallidusEBoundRotatedVd;

/* extern    dblVec    pallidusEQuadrVd; */

#endif
/******************************************************************************/
/******************************************************************************/
