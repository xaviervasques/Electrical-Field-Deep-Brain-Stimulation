/*  ../libmy/utiLec.h                                                         */
/*  Mennessier Gerard                   941223                                */
/*  Last Revised : M.G.                 991025                                */

#ifndef  DEF_UTILEC_H
#define  DEF_UTILEC_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiBookChr.h"

#ifndef SEEK_SET                  /* defined in stdio.h if ANSI, unistd.h if SPARC */
#define SEEK_SET        0                          /* Set file pointer to "offset" */
#endif

char      *lec1all(FILE *, size_t *);
chrBook   *lec2all(FILE *);
chrBook   *lec3all(FILE *);
chrBook   *leckbd(FILE *stream);
FILE      *getFileStream(char *form1, char *form2, char *form3);
FILE      *getFileNameAndStream(char *mess1,char *mess2);
chrBook   *lec2(char *);
chrBook   *lec3(char *);

#endif
/******************************************************************************/
/******************************************************************************/
