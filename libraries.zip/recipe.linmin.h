/*  libc/recipe2double/recipe.linmin.h                                        */
/** VECTOR and MATRIX INDICES FROM 0 to DIM-1                                **/
/** VECTOR and MATRIX : DOUBLE version                                       **/

#ifndef  DEF_LINMIN_H
#define  DEF_LINMIN_H

void      linmin(double p[], double xi[], int n, double *fret, double tol);
double    linminf1dim(double x);
void      linminAlloc(int n, double (*func)(double []));
void      linminFree();

#endif
/******************************************************************************/
/******************************************************************************/
