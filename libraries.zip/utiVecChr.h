/*  ../libmy/utiVecChr.h                                                      */
/*  Mennessier Gerard                   19940822                              */
/*  Last revised : M.G.                 20020213                              */

#ifndef  DEF_UTIVECCHR_H
#define  DEF_UTIVECCHR_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiAlloc.h"

typedef struct chrVec
{ size_t        z;                                             /** allocated size **/
  size_t        x;                                                  /** used size **/
  char         *p;
} chrVec, *chrVecp;

#define  chrVecAlloc(nz,prognamp)            (chrVec *)myVecAlloc((nz),prognamp)
#define  chrVecChkRealloc(p,nzp,needz,inz,pronamp)              \
                              (chrVec *)myVecChkRealloc(p,nzp,needz,inz,pronamp)

extern    void      chrPVecAlloc  (chrVec *vecp,size_t nz);
extern    void      chrPVecRealloc(chrVec *vecp,size_t neednz,size_t incrnz);
extern    void      chrPVecFree   (chrVec *vecp);
extern    void      chrVecFree    (chrVec *vecp);
extern    void      chrVecPrint   (FILE  *bufp,chrVec *vecp);
extern    void      chrVecXPrint   (FILE  *bufp,chrVec *vecp);
extern    void      chrVecInc1    (chrVec *vecp,char c);
extern    void      chrVecIncN    (chrVec *vecp,char *memp,size_t n);
extern    void      chrVecEnd(chrVec *vecp,int c);
extern    void      chrVecIncStr(chrVec *vecp,char *cp);
#define   chrVecZero(vec)        (vec).x = 0

#endif
/******************************************************************************/
/******************************************************************************/
