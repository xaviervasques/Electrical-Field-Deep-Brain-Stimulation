/*  libc/recipe2double/recipe.ludcmp.h                                        */
/** VECTOR and MATRIX INDICES FROM 0 to DIM-1                                **/
/** VECTOR and MATRIX : DOUBLE version                                       **/

#ifndef  DEF_LUDCMP_H
#define  DEF_LUDCMP_H

void      ludcmp(double **a, int n, int *indx, double *d);

#endif
/******************************************************************************/
/******************************************************************************/
