/*  libc/recipe2double/recipe.lubksb.h                                        */
/** VECTOR and MATRIX INDICES FROM 0 to DIM-1                                **/
/** VECTOR and MATRIX : DOUBLE version                                       **/

#ifndef  DEF_LUBKSB_H
#define  DEF_LUBKSB_H

void      lubksb(double **a, int n, int *indx, double *b);

#endif
/******************************************************************************/
/******************************************************************************/
