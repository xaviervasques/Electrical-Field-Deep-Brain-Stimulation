/*  libc/recipe2double/recipe.frprmn.h                                        */
/** VECTOR and MATRIX INDICES FROM 0 to DIM-1                                **/
/** VECTOR and MATRIX : DOUBLE version                                       **/

       /**  (*func)(double p[]) should compute the (scalar) value of the function **/
              /** (*dfunc)(double p[], double grad[]) should compute the gradient **/

#ifndef  DEF_FRPRMN_H
#define  DEF_FRPRMN_H

void      frprmn(double p[], int n, double ftol, int *iter, double *fret,
          double (*func)(double []), void (*dfunc)(double [], double []), int itmax);

#endif
/******************************************************************************/
/******************************************************************************/
