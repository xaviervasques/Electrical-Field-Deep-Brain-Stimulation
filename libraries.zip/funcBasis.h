#ifndef  DEF_FUNCBASIS_H
#define  DEF_FUNCBASIS_H

void      fbasisSetR(double rayon);
double    fbasis(double xyz[3], double centerxyz[3]);
void      fbasisGrad(double *fgradp, double *currentxyzp, double *centerxyzp);
double    fbasisValGrad(double *fgradp, double *currentxyzp, double *centerxyzp);

#endif
/******************************************************************************/
/******************************************************************************/
