/*  ../libmy/utiBookChr.h                                                     */
/*  Mennessier Gerard                   940822                                */
/*  Last revised : M.G.                 991025                                */

#ifndef  DEF_UTIBOOKCHR_H
#define  DEF_UTIBOOKCHR_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiAlloc.h"
#include  "utiVecPtr.h"

typedef struct chrBook
{ size_t        bz;
  size_t        bx;
  char         *bp;
  size_t        iz;  
                 /** number of memory allocated to store the offsets of char sets **/
        /** Need iz>=ix+1 because last offset added to point on first free memory **/
  size_t        ix;                 
                                             /** number of char set. Need ix < iz **/
  ptrdiff_t    *ip;        
                                               /** ip,ip+1.. point on the offsets **/
                          /** usually *ip=0, *(ip+ix) points on first free memory **/
} chrBook, *chrBookp;

#define  chrBookAlloc(nz,prognamp)       (chrBook *)myBookAlloc((nz),prognamp)
#define  chrBookChkRealloc(nz,prognamp)  (chrBook *)myBookChkRealloc((nz),prognamp)
/* extern    chrBook  *chrBookAlloc   (size_t nz, char *prognamp); */

extern    void      chrBBookAlloc  (chrBook *bookp,size_t  nz);
extern    void      chrBBookRealloc(chrBook *bookp,size_t neednz,size_t incrnz);
extern    void      chrIBookAlloc  (chrBook *bookp,size_t  nz);
extern    void      chrIBookRealloc(chrBook *bookp,size_t neednz,size_t incrnz);
extern    void      chrBBookFree   (chrBook *bookp);
extern    void      chrIBookFree   (chrBook *bookp);
extern    void      chrBookFree    (chrBook *bookp);
extern    void      chrBookCPrint   (FILE  *bufp, chrBook *bookp);
extern    void      chrBookXPrint  (FILE  *bufp, chrBook *bookp);
extern    void      chrBookStrPrint(FILE  *bufp, chrBook *bookp);
extern    void      chrBookIPrint  (FILE  *bufp, chrBook *bookp);
extern    void      chrBookInc1Mem (chrBook *bookp,char *cp,size_t n);
extern    void      chrBookEnd     (chrBook *bookp,int c);
extern    void      chrBookInc1Str (chrBook *bookp,char *cp);
extern    void      chrBookEnlargeLast (chrBook *bookp,char *cp,size_t n);
extern    void      chrBookDecreaseLast(chrBook *bookp,size_t n);
extern    void      chrBookRemoveLast  (chrBook *bookp);

#define   chrBookZero(book)        (book).bx = 0;   (book).ix = 0;   *((book).ip)   = 0
#define   chrBookpZero(bookp)      (bookp)->bx = 0; (bookp)->ix = 0; *((bookp)->ip) = 0
#define   chrBookIthInd(book,i)   *((book).ip + (i))   
#define   chrBookGetIthP(bookp,i)  (bookp)->bp + *((bookp)->ip +(i))

extern    ptrVec   *chrBook2ptrVec(ptrVec *vecp,chrBook *cBp);
extern    char    **chrBook2chrpp(chrBookp cBp);

#endif
/******************************************************************************/
/******************************************************************************/
