/*  essai/C/utiCurve.string.h                                                 */
/*  Mennessier Gerard                   20010502                              */
/*  Last revised M.G.                   20020904                              */
/*                                                                            */

#ifndef  DEF_UTICURVE_STRING_H
#define  DEF_UTICURVE_STRING_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiAlloc.h"
#include  "utiCurve.GC.h"

/******************************************************************************/
/*  cStr : string                                                             */
/******************************************************************************/
typedef struct curveString
{ double        xyp[2];       /** position of string **/
  char         *strp;         /** pointer to string to be drawn **/
} cStr, *cStrp;

cStr     *cStrAlloc(size_t nz, char *progcallp);
cStr     *cStrChkRealloc(cStr *pi, size_t *nzp, size_t neednz, size_t incrnz,
                                                                    char *progcallp);
void      cStrZero(cStr *p);

/******************************************************************************/
/*  cStrVec                                                                   */
/******************************************************************************/
typedef struct cStrVec
{ size_t        z;
  size_t        x;
  cStr         *p;
  curveGC      *gcp;          /** pointer to associated GC **/
  double        fscalp[2];    /** x and y font scale **/
  int           findex;       /** pointer to font info **/
} cStrVec, *cStrVecp;

cStrVec  *cStrVecAlloc(size_t nz, char *progcallp);
cStrVec  *cStrVecChkRealloc(cStrVec *pi, size_t *nzp, size_t neednz, size_t incrnz, 
                                                                    char *progcallp);
void      cStrPVecAlloc(cStrVec *vecp,size_t nz);
void      cStrPVecRealloc(cStrVec *vecp, size_t neednz, size_t incrnz);
void      cStrPVecFree(cStrVec *vecp);
void      cStrVecFree(cStrVec *vecp);

#endif
/******************************************************************************/
/******************************************************************************/
