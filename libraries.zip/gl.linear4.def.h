/*  URMAE/numerical/linearGL4/gl.linear4.def.h                                */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20030509                                */

#ifndef  DEF_GL_LINEAR4_DEF_H
#define  DEF_GL_LINEAR4_DEF_H

#define  MY_GL_WIN_NUMBER   56
#define  MY_GL_MENU_NUMBER  13

#define  myWIN_0       0

#define  myWIN_00      5
#define  myWIN_000     6
#define  myWIN_001     7

#define  myWIN_01     10
#define  myWIN_010    11
#define  myWIN_011    12
#define  myWIN_012    13
#define  myWIN_013    14

#define  myWIN_02     20
#define  myWIN_020    21
#define  myWIN_021    22
#define  myWIN_022    23
#define  myWIN_023    24

#define  myWIN_03     25
#define  myWIN_030    26
#define  myWIN_031    27
#define  myWIN_032    28
#define  myWIN_033    29


#define  myWIN_04     30
#define  myWIN_040    31
#define  myWIN_041    32
#define  myWIN_042    33
#define  myWIN_043    34


#define  myWIN_1      35
#define  myWIN_2      40

#define  myWIN_3      55

#define  myWIN_4      45
#define  myWIN_5      50
#endif
/******************************************************************************/
/******************************************************************************/
