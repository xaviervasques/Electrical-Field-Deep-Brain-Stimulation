/*   ..libmy/utistdStr.h                                                      */
/*   Mennessier Gerard             940822                                     */
/*   Last revised M.G.             950824                                     */

#ifndef  DEF_UTISTDSTR_H
#define  DEF_UTISTDSTR_H

#include  <stddef.h>

#define  DEF_MAPSTR
/* #undef  DEF_MAPSTR */

#ifdef  SPARCM

extern char   *strcat(char *, const char *);
extern char   *strchr(const char *, int);
extern int     strcmp(const char *, const char *);
extern int     strcoll(const char *, const char *);   
extern char   *strcpy(char *, const char *);
extern size_t  strcspn(const char *, const char *);
                                         /*****  extern char *strerror(int);  ******/
extern size_t  strlen(const char *);
extern char   *strncat(char *, const char *, size_t);
extern int     strncmp(const char *, const char *, size_t);
extern char   *strncpy(char *, const char *, size_t);
extern char   *strpbrk(const char *, const char *);
extern char   *strrchr(const char *, int);
extern size_t  strspn(const char *, const char *);
extern char   *strstr(const char *, const char *);
extern char   *strtok(char *, const char *);

extern double  strtod(const char *, char **);    /** SPARC: in floatingpoint.h !! **/
extern long int strtol(const char *, char **, int);     /** SPARC: not defined !! **/
                /** extern unsigned long int strtoul(const char *, char **, int); **/
                                             /** SPARC: strtoul does NOT exist !! **/

#else
#include  <string.h>
#include  <stdlib.h>                         /** for strtod,strtol,strtoul (ANSI) **/
#endif                                                          /** ifdef  SPARCM **/

#ifdef   DEF_MAPSTR

#define   strChr    strchr
#define   strCmp    strcmp
#define   strCpy    strcpy
#define   strLen    strlen    
 
#else
extern    char     *strChr(const char *,int);
extern    int       strCmp(const char *,const char *);
extern    char     *strCpy(char *,const char *);
extern    size_t    strLen(const char *);
#endif                                                      /** ifdef  DEF_MAPSTR **/

#endif                                                /** ifndef  DEF_UTISTDSTR_H **/
/******************************************************************************/
/******************************************************************************/
