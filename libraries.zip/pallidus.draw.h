/*  URMAE/orientHaut/linear4.GL.V1/pallidus.draw.h                            */
/*  Mennessier Gerard                 20000414                                */
/*  Last Revised : G.M.               20011220                                */

#ifndef   DEF_PALLIDUS_DRAW_H
#define   DEF_PALLIDUS_DRAW_H

#include  "utistdIO.h"
#include  "utiCurve.level.h"
#include  "utiCurve.set.h"

void      pallidusInitDraw();

lcSegVec *pallidusERZGetlcSeg();
lcSegVec *pallidusEXYGetlcSeg();
void      pallidusEComputeRZSection(lcSegVec *lcsegvecp, double y, int iy);
void      pallidusEComputeXYSectionRotated(lcSegVec *lcsegvecp, double z, int iz);

lcSegVec *pallidusSTRZGetlcSeg();
lcSegVec *pallidusSTXYGetlcSeg();
void      pallidusSTComputeRZSection(lcSegVec *lcsegvecp, double y, int iy);
void      pallidusSTComputeXYSection(lcSegVec *lcsegvecp, double z, int iz);

cSetVec  *pallidusSTallXYGetSetV();
void      pallidusSTallXYdataZsection(cSetVec *csetvecp);

void      pallidusSTallXYZaxisGL();
void      pallidusSTallXYZaxisGLlist();
void      pallidusSTallXYdataZsectionGL();
void      pallidusSTallXYdataZsectionGLlist();
void      pallidusSTallXYdataZquadGL();
void      pallidusSTallXYdataZquadGLlist();
void      pallidusSTallXYdataZquadfillGL();
void      pallidusSTallXYdataZquadfillGLlist();

#endif
/******************************************************************************/
/******************************************************************************/
