/*   ..libmy/utiMemStr.h                                                      */
/*   Mennessier Gerard             960327                                     */
/*   Last revised M.G.             960506                                     */

#ifndef  DEF_UTIMEMSTR_H
#define  DEF_UTIMEMSTR_H

#include  <stddef.h>

int       memStrUcmp(void *mp, size_t ix, unsigned char *sp);
int       memStrClas(char  *spp[],int strnb,void *mp,size_t ix,int *indexp);
int       memStrEq(void *mp,size_t ix,char *sp);
int       memStrRank(char  *spp[],int strnb,void *mp,size_t ix);

#endif                                            
/******************************************************************************/
/******************************************************************************/
