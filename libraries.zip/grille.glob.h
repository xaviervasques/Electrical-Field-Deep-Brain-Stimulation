#ifndef  DEF_GRILLE_GLOB_H
#define  DEF_GRILLE_GLOB_H

#include  "utiVecDbl.h"

extern size_t    grilleSizep[3];
extern size_t    TailleX, TailleY, TailleZ;
extern double    grilleSizeM1dp[3];

extern double    grilleDimensiondp[3];

extern dblVec    grilleValuesVec;
extern double   *grilleValuesp;
extern double  **grilleValuespp;

extern double    IsoLeveld;

#endif
/******************************************************************************/
/******************************************************************************/
