/*  bio_phys/URMAE/numerical/linearGL4/gl.linear4.04.h                        */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20030509                                */

#ifndef  DEF_GL_LINEAR4_04_H
#define  DEF_GL_LINEAR4_04_H

void      gmGl04InitWin(void);
void      gmGl04Display(void);
void      gmGl04Reshape(int w, int h);

void      gmGl040InitWin(void);
void      gmGl040Display(void);
void      gmGl040Reshape(int w, int h);
void      gmGl040KB(unsigned char key, int x, int y);
void      gmGl041InitWin(void);
void      gmGl041Display(void);
void      gmGl041Reshape(int w, int h);
void      gmGl041KB(unsigned char key, int x, int y);
void      gmGl042InitWin(void);
void      gmGl042Display(void);
void      gmGl042Reshape(int w, int h);
void      gmGl043InitWin(void);
void      gmGl043Display(void);
void      gmGl043Reshape(int w, int h);
void      gmGl043MN(int menuindex);
void      gmGl043MN1(void);
void      gmGl043MN2(void);
void      gmGl043MN3(void);
void      gmGl043MN123();

#endif
/******************************************************************************/
/******************************************************************************/
