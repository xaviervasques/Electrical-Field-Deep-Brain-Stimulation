/*  URMAE/orientHaut/linear4.GL.V1/gm.linear4.initsolve.statalloc.h           */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20020410                                */

#ifndef  DEF_GM_LINEAR4_INITSOLVE_STATALLOC_H
#define  DEF_GM_LINEAR4_INITSOLVE_STATALLOC_H

#include  "utiTnsr.h"

#include  "gridZ.linear4.h"
#include  "gridR.linear4.h"
#include  "varGrid.linear4.h"
#include  "cylPot.linear4.h"
#include  "eltrdPot.linear4.h"
#include  "pot.linear4.h"
#include  "varPot.linear4.h"

static    gmGridZ   gridZi;
static    gmGridR   gridRi;
static    gmVarGrid varGridi;

static    gmEltrdPot     eltrdPbasp[4];
static    gmCylPot       cylPbasp[4];
static    gmPot     Vbasp[4];
static    gmVarPot  varVbasp[4];

static    tnsr2dbl  gAt;
static    tnsr2dbl  sAt, sBt;
static    gmVarPot  varVf;

#endif
/******************************************************************************/
/******************************************************************************/
