#ifndef  DEF_GLDRAW_PALLIDUS_H
#define  DEF_GLDRAW_PALLIDUS_H

void      glDrawTriangles();
int       glDrawCell(int ix, int iy, int iz);
int       glDrawSetElemCube(int ix, int iy, int iz);

#endif
/******************************************************************************/
/******************************************************************************/
