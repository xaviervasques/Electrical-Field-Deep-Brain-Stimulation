/*  URMAE/numerical/linear4/varGrid.linear4.h                                 */
/*  Mennessier Gerard                 20000414                                */
/*  Last Revised : G.M.               20010523                                */

#ifndef  DEF_VARGRID_LINEAR4_H
#define  DEF_VARGRID_LINEAR4_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "gridZ.linear4.h"
#include  "gridR.linear4.h"

typedef struct gmVarGridStruct
{ gmGridR  *gridRp;
  gmGridZ  *gridZp;
  double    rLimsp[8]; 
  double    r2Limsp[8];
  int       izLimFp[8];
  int       izLimLp[8];
                   /** for each iz, ir index of first and last variable potential **/
  int      *irnd_firstp;
  int      *irnd_lastp;
                               /** for each iz, index of first varPot of the line **/
  int      *iv_firstp;
  int       iznd_first;
  int       iznd_last;
  int       cylcond;    /** -1 full insulator, 0 neck conductor, 1 full conductor **/
  size_t    ndx;                   /** effective number of nodes for minimization **/
} gmVarGrid, *gmVarGridp;

void      gmVarGridPAlloc(size_t ndz, gmVarGrid *p);
int       gmVarGridInit(gmVarGrid *p, gmGridR *gridRp, gmGridZ *gridZp, int *orderp);
void      gmVarGridPrint(FILE *bufOut, gmVarGrid *p);

#endif
/******************************************************************************/
/******************************************************************************/
