/*  bio_phys/URMAE/numerical/xxxx/pot_funcBasis.h                             */
/*  Mennessier Gerard                 20000415                                */
/*  Last Revised : G.M.               20000609                                */

#ifndef  DEF_POT_FUNCBASIS_H
#define  DEF_POT_FUNCBASIS_H

#include  "pot_funcBasis.def.h"

double    angle(double par[NCOEF_],int order,double rho,double zeff);
void      anglePerpTOcoefs(double parp[2], int order, double valuesp[2],
                                                           double diz, double rhoti);
double    angleTOintensity0(double par[NCOEF_],int order, double deltaz);
double    angleTOaction(double par[NCOEF_],int order, double deltaz, double rhot);
double    mono_quadru(double par[NINFINITYX_],double rho,double z);
#endif
/******************************************************************************/
/******************************************************************************/
