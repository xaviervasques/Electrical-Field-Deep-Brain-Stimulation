/*  bio_phys/URMAE/numerical/linearGL4/gl.linear4.01.glob.h                   */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20030509                                */

#ifndef  DEF_GL_LINEAR4_04_GLOB_H
#define  DEF_GL_LINEAR4_04_GLOB_H

#include  <GL/glut.h>
#include  "utiVecChr.h"

/* Console Window */
/* Threshold Parameters */

extern    GLfloat   win04ew, win04eh,
                    win040ew, win040eh, win041ew, win041eh, win042ew, win042eh,
                                                                  win043ew, win043eh;

extern    GLfloat   rs04w, rs04h;
extern    GLfloat   rs040w, rs041w, rs042w, rs043w;
extern    GLfloat   rs040h, rs041h, rs042h, rs043h;
extern    GLfloat   p04w, p04h;
extern    GLfloat   p040w, p041w, p042w, p043w;
extern    GLfloat   p040h, p041h, p042h, p043h;

extern    chrVec    thresholdV,
                    newThresholdV,
                    volumeGlobalV,
                    volumePallidusV;

extern    double    threshold,
                    volumeGlobal,
                    volumePallidus;

extern    char      defaultThresholdstrp;

#endif
/******************************************************************************/
/******************************************************************************/
