/*  URMAE/orientHaut/linear4.GL.V1/pallidus.draw.statalloc.h                  */
/*  Mennessier Gerard                 20010703                                */
/*  Last Revised : G.M.               20011221                                */

#ifndef  DEF_PALLIDUS_DRAW_STATALLOC_H
#define  DEF_PALLIDUS_DRAW_STATALLOC_H

#include  "utiVecDbl.h"
#include  "utiVecInt.h"

#include  "utiCurve.level.h"
#include  "utiCurve.poly.h"
#include  "utiCurve.set.h"

                              /** ScannerTranslated Frame pallidus boundary coord **/
                                 /** reconstructed from data. May have more points**/
static    lcSegVec  pallidusSTRZSegV, pallidusSTXYSegV;

static    cSetVec   pallidusSTallXYSetV;                       /** for all planes **/

                                      /** Electrode Frame pallidus boundary coord **/
   /** ElectrodeFrame boundary coord after final psi rotation around Oz electrode **/
static    lcSegVec  pallidusERZSegV, pallidusEXYSegV;

#endif
/******************************************************************************/
/******************************************************************************/
