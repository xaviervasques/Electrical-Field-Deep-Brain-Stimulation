/*   ..libmy/utiStr.h                                                         */
/*   Mennessier Gerard             940822                                     */
/*   Last revised M.G.             970701                                     */

#ifndef  DEF_UTISTR_H
#define  DEF_UTISTR_H

#include  <stddef.h>

#define   strSkipChr     strCpySkipChr
#define   strSkipStr     strCpySkipStr

extern    char     *strChr2(const char *sp,int c1,int c2,int *valuep);
extern    char     *strDiffChr(const char *sp,int c);
extern    int       strUcmp(unsigned char *s1p,unsigned char *s2p);
extern    char     *strCpyP(char *,const char *);
extern    char     *strMove(char *sfp,const char *sip);
extern    int       strEq(char *,char *);
extern    char     *strGetNextSpe (char  *,int);
extern    char     *strGetNextSpes(char  *,char *);
extern    char     *strGetNextDiff(char  *sp,int c);

extern    long      strAtoL(const char *);
extern    char     *strCpySkipChr(char *, const char  *, int);
extern    char     *strCpySkipStr(char *, const char  *, char *);
extern    char     *strNormalizeSpace(char *sfp,    char *sip);

extern    int       strRank(char **spp,int ,char *);
extern    int       strClas(char  *str[],int,char *,int *);
extern    void      strHalfSum(unsigned char *strfp,
                                  int *sp,unsigned char *str2p,unsigned char *str1p);

#endif                                                   /** ifndef  DEF_UTISTR_H **/
/******************************************************************************/
/******************************************************************************/
