Ligne de Champs; Surface Intersection; Surface In; Surface Out
 
 0.200000, 3.087738, 2.650143, 0.437592 
