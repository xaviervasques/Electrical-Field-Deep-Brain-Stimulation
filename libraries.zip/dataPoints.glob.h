#ifndef  DEF_DATAPOINTS_GLOB_H
#define  DEF_DATAPOINTS_GLOB_H

#include  <stddef.h>
#include  "utiVecDbl.h"

extern size_t         NPTS;
extern size_t         Np;

extern dblVec         ptsInitVec;
extern double         ptsInitMinp[3],  ptsInitMaxp[3];

              /** translation initiale de recentrage  vers electrode et pallidus **/
extern double         cg[3];
                                 /** position centre electrode dans repere stereo **/
extern double         targetp[3];
extern double         targetp2[3];
extern double         targetp3[3];
extern double         targetp4[3];
extern double         targetp5[3];
extern double         targetp6[3];
extern double         targetp7[3];
extern int            Gpiside;
extern double         thetaEl, phiEl;
extern double         thetaEl2, phiEl2;
extern double         thetaEl3, phiEl3;
extern double         thetaEl4, phiEl4;
extern double         thetaEl5, phiEl5;
extern double         thetaEl6, phiEl6;
extern double         thetaEl7, phiEl7;

extern dblVec         ptsCentresVec;
extern double        *ptsCentresp;
extern double         ptsCentresMinp[3],  ptsCentresMaxp[3];
extern double         ptsCentresMin,      ptsCentresMax;

extern double         typicalSize;

extern dblVec         weightVec;

#endif
/******************************************************************************/
/******************************************************************************/
