/*  ../linear4.Common/gridZ.linear4.h                                         */
/*  Mennessier Gerard                 20000414                                */
/*  Last Revised : G.M.               20020325                                */

#ifndef  DEF_GRIDZ_LINEAR4_H
#define  DEF_GRIDZ_LINEAR4_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiAlloc.h"

#include  "eltrd.def.h"

/** **************************************** ****************************************
                                   | approximate symetry axis
                                   | 
     D-4    D-3    D-2    D-1     D0    D+1    D+2    D+3    D+4
 ...      |      |      |      |      |      |      |      |        |          )
     insL   cndL   insL   cndL   insL   cndL   insL   cndL  eltrdCyl  eltrdEll
         pe0    pe1    pe2    pe3    pe4    pe5    pe6    pe7      
**************************************** **************************************** **/

typedef struct gmGridZStruct
{ char     *unitnamep;        /** UNIT **/
  double   *zndp;                                          /** z node coordinates **/
  size_t    zndz;
  size_t    zndx;
  double   *zllp;                                              /** z-link lengths **/
  size_t    zllz;
  size_t    zllx;
  double    eltrdR;                                          /** Electrode Radius **/
  double    zndMIN;                                         /**  zmin coordinates **/
  double    zndMAX;                                           /** zmax coordinate **/
  double    insL;                                            /** Insulator length **/
  double    cndL;                                            /** Conductor length **/
                              /** For Pin Extremities **/
  double    pinExtZp[NPEX_];                    /** Pin Extremities z-coordinates **/
  int       pinExtIp[NPEX_];                     /** Pin Extremities node-indices **/
  int       pinExtX;                          /** Pin Extremities number = 2*pinx **/
  int       pinX;                                                  /** Pin number **/
                              /** Approximate Symmetry Plane **/
  double    symPlZ;                  /** Approximate Symmetry Plane z-coordinates **/
  int       symPlI;                                 /** Symmetry Plane node-index **/
                              /** For Ellipsoidal Electrode Extremity **/
  double    eltrdExtCyl;       /** Electrode extremity insulator cylinder  length **/
  double    eltrdExtEll;       /** Electrode extremity insulator ellipsoid length **/
  double    eltrdExtZp[2];                  /** Electrode extremity z-coordinates **/
  int       eltrdExtIp[2];              /** Electrode extremity-indices (z nodes) **/
  int       eltrdExtX;                     /** Electrode extremity-indices number **/
                                                              /** Global Geometry **/
                               /** for each iz, index of first irGeom in the line **/
  int      *irGeond_firstp;
                               /** for each iz, index of last  irGeom in the line **/
  int      *irGeond_lastp;          /** all will have same value if true cylinder **/
                         /** for each iz, index of first pot of the line in total **/
                                            /** i.e. Cumulated effective ir nodes **/
  int      *ivGeo_firstp;
} gmGridZ, *gmGridZp;

gmGridZ  *gmGridZAlloc(size_t nz, char *progcallp);
void      gmGridZPAlloc(size_t llz, gmGridZ *p);
int       gmGridZinit(FILE *bufOut, gmGridZ *p, double *infozpap, int *infopinzpaxp);
void      gmGridZprint(FILE *bufOut, gmGridZ *p);
void      gmGridZCpy(char *unitp, double scale, gmGridZ *pf, gmGridZ *pi);
int       gmGridZreadINI(FILE *bufGridZinitp, double *infozpap, int *infopinzpaxp);
double    gmGridZGeoZ2R(double z, gmGridZ *Zp);

#endif
/******************************************************************************/
/******************************************************************************/
