/*  URMAE/orientHaut/linear4.GL.V2/gm.drawstate.h                             */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20030512                                */

#ifndef  DEF_GM_DRAWSTATE_H
#define  DEF_GM_DRAWSTATE_H

#include  "utiVecChr.h"
#include  "utiCurve.level.h"

void      gmDrawStateInit();
chrVec   *gmDrawStateGetPatient();
void      gmDrawStateSetPatient(chrVec *patientNameVp);
chrVec   *gmDrawStateGetPinMode();
void      gmDrawStateSetPinMode(chrVec *pinModVp);
chrVec   *gmDrawStateGetVoltage();
void      gmDrawStateSetVoltage(chrVec *voltageVp);
chrVec   *gmDrawStateGetImpedance();
void      gmDrawStateSetImpedance(chrVec *impedanceVp);
int       gmDrawStateGetVEI();
void      gmDrawStateSetVEI(int vei);
void      gmDrawStateSetLevelMult();
void      gmDrawStateSetLevelSingle(int vei, double levelValue);
lcZrange *gmDrawStateGetLCrange();
void      gmDrawStatePrintLCrange();

double    gmDrawStateSolveFromBasis();

char    **gmDrawStateGetTitles();

double    gmDrawStateHWScaleRatioA4Width2Height(double scratiohw, double deltaw);
double    gmDrawStateHWScaleRatioA4Height2Width(double scratiohw, double deltah);

#endif
/******************************************************************************/
/******************************************************************************/
