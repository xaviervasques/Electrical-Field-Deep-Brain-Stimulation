/*  bio_phys/URMAE/numerical/linearGL4/gl.linear4.03.h                        */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20010823                                */

#ifndef  DEF_GL_LINEAR4_03_H
#define  DEF_GL_LINEAR4_03_H

void      gmGl03InitWin(void);
void      gmGl03Display(void);
void      gmGl03Reshape(int w, int h);

void      gmGl030InitWin(void);
void      gmGl030Display(void);
void      gmGl030Reshape(int w, int h);
void      gmGl030KB(unsigned char key, int x, int y);
void      gmGl030MN(int menuindex);

void      gmGl031InitWin(void);
void      gmGl031Display(void);
void      gmGl031Reshape(int w, int h);
void      gmGl031KB(unsigned char key, int x, int y);
void      gmGl031MN(int menuindex);

void      gmGl032InitWin(void);
void      gmGl032Display(void);
void      gmGl032Reshape(int w, int h);
void      gmGl032KB(unsigned char key, int x, int y);
void      gmGl032MN(int menuindex);

void      gmGl033InitWin(void);
void      gmGl033Display(void);
void      gmGl033Reshape(int w, int h);
void      gmGl033MN(int menuindex);

#endif
/******************************************************************************/
/******************************************************************************/
