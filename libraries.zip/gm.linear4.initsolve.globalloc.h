/*  URMAE/orientHaut/linear4.GL.V1/gm.linear4.initsolve.globalloc.h           */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20020410                                */

#ifndef  DEF_GM_LINEAR4_INITSOLVE_GLOBALLOC_H
#define  DEF_GM_LINEAR4_INITSOLVE_GLOBALLOC_H

#include  "gridZ.linear4.h"
#include  "gridR.linear4.h"
#include  "cylPot.linear4.h"
#include  "eltrdPot.linear4.h"
#include  "pot.linear4.h"

gmGridZ        gridZi_mm;
gmGridR        gridRi_mm;
gmEltrdPot     eltrdPf;
gmCylPot       cylPf;
gmPot          Vf,  gradVf;

#endif
/******************************************************************************/
/******************************************************************************/
