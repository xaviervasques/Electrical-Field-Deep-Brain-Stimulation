/*  URMAE/orientHaut/linear4.GL.V1/gm.draw.ST.h                               */
/*  Mennessier Gerard                 20000414                                */
/*  Last Revised : G.M.               20020419                                */

#ifndef  DEF_GM_DRAW_ST_H
#define  DEF_GM_DRAW_ST_H

#include  "utistdIO.h"
#include  "utiCurve.level.h"
#include  "utiCurve.seg.h"
#include  "utiCurve.set.h"
#include  "utiCurve.string.h"
#include  "gridZ.linear4.h"
#include  "gridR.linear4.h"
#include  "cylPot.linear4.h"
#include  "eltrdPot.linear4.h"
#include  "grid_pot.ST.linear4.h"

void      gmDrawSTGetRZeltrdAxis(cSetVec *csetvp,
                                             gmGridZ *gridZp_mm, gmGridR *gridRp_mm);
cSegVec  *gmDrawSTGetRZtraceXYsection(double zh);

void      gmDrawSTGetXYeltrdAxis(cSetVec *csetvp,
                                  gmGridZ *gridZp_mm, gmGridR *gridRp_mm, double zh);
cSegVec  *gmDrawSTGetXYtraceRZsection(double psi);

void      gmDrawSTComputeRZLevels(cSetVec *csetvp);
void      gmDrawSTComputeXYLevels(cSetVec *csetvp, lcZrange *lczrp, gmGridPotSTXY *p);
cStrVec  *gmDrawSTGetRZCStrTitle(char **titlespp, int vei, char **STtitlespp);
cStrVec  *gmDrawSTGetXYCStrTitle(char **titlespp, int vei, char **STtitlespp);
cStrVec  *gmDrawSTGetCStrPinIndices();
short     gmDrawSTfromEtoRZpsi(double *coorST, double rhoE, double zE);
void      gmDrawSTSetGeomRZ();

#endif
/******************************************************************************/
/******************************************************************************/
