/*  libc/recipe2double/recipe.brent.h                                         */
/** VECTOR and MATRIX : DOUBLE version                                       **/

#ifndef  DEF_BRENT_H
#define  DEF_BRENT_H

double    brent(double ax, double bx, double cx, double (*f)(double),
                                                           double tol, double *xmin);

#endif
/******************************************************************************/
/******************************************************************************/
