/*  bio_phys/URMAE/numerical/linearGL4/gl.linear4.01.h                        */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20010828                                */

#ifndef  DEF_GL_LINEAR4_01_H
#define  DEF_GL_LINEAR4_01_H

void      gmGl01InitWin(void);
void      gmGl01Display(void);
void      gmGl01Reshape(int w, int h);

void      gmGl010InitWin(void);
void      gmGl010Display(void);
void      gmGl010Reshape(int w, int h);
void      gmGl010KB(unsigned char key, int x, int y);
void      gmGl011InitWin(void);
void      gmGl011Display(void);
void      gmGl011Reshape(int w, int h);
void      gmGl011KB(unsigned char key, int x, int y);
void      gmGl012InitWin(void);
void      gmGl012Display(void);
void      gmGl012Reshape(int w, int h);
void      gmGl012KB(unsigned char key, int x, int y);
void      gmGl013InitWin(void);
void      gmGl013Display(void);
void      gmGl013Reshape(int w, int h);
void      gmGl013MN(int menuindex);
void      gmGl013MN1(void);
void      gmGl013MN2(void);
void      gmGl013MN3(void);
void      gmGl013MN123();

#endif
/******************************************************************************/
/******************************************************************************/
