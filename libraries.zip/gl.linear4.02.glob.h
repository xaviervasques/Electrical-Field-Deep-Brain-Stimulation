/*  bio_phys/URMAE/numerical/linearGL4/gl.linear4.02.glob.h                   */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20010827                                */

#ifndef  DEF_GL_LINEAR4_02_GLOB_H
#define  DEF_GL_LINEAR4_02_GLOB_H

#include  <GL/glut.h>
#include  "utiVecChr.h"

/*
0  ConsoleRoot
1  sub 0     00     Patient
2  sub 1    000     Menu OK/CANCEL changement patient
3  sub 0     01     Caracteristiques electriques
4  sub 3    010     Pin modes
5  sub 3    011     Voltage
6  sub 3    012     Impedance
7  sub 3    013     Menu OK/CANCEL 
*/

extern    GLfloat   win02ew, win02eh,
                    win020ew, win020eh, win021ew, win021eh, win022ew, win022eh,
                                                                  win023ew, win023eh;

extern    GLfloat   rs02w,  rs02h;
extern    GLfloat   rs020w, rs021w, rs022w, rs023w;
extern    GLfloat   rs020h, rs021h, rs022h, rs023h;
extern    GLfloat   p02w,   p02h;
extern    GLfloat   p020w,  p021w,  p022w,  p023w;
extern    GLfloat   p020h,  p021h,  p022h,  p023h;

extern    char     *veiStrpp[];
extern    char      veiChrp[3];
extern    int       VEI;

extern    chrVec    psiEltrdRotV;
extern    double    psiEltrdRot;

#endif
/******************************************************************************/
/******************************************************************************/
