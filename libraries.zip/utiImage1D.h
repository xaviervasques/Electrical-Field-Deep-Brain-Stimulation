/*  ../libmy/utiImage1D.h                                                     */
/*  Mennessier Gerard                   20031008                              */
/*  Last revised M.G.                   20040503                              */

#ifndef  DEF_UTIIMAGE1D_H
#define  DEF_UTIIMAGE1D_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiVecChr.h"
#include  "utiImage0D.h"

/******************************************************************************/
typedef struct utiImage1D
{ utiImage0D     im0D;
  chrVec         dataV;                                     /** image 1 line data **/
  size_t         wpx;                             /** width, PIXEL number per row **/
  unsigned int   graymin;                                  /** minimum gray value **/
  unsigned int   graymax;                                  /** maximum gray value **/
} utiImage1D, *utiImage1Dp;

/******************************************************************************/

void      utiImage1DdataPVecAlloc(utiImage1D *ep, size_t nz);
void      utiImage1DdataPVecRealloc(utiImage1D *ep, size_t neednz, size_t incrnz);
void      utiImage1DdataPVecFree(utiImage1D *ep);
void      utiImage1DdataBytesPrint(FILE *streamp, utiImage1D *ep);
void      utiImage1DZero(utiImage1D *ep);
void      utiImage1DPrint(FILE *streamp, utiImage1D *ep);

              /** Relevant ONLY when pixels are ushort GRAY LEVELS (or luminance) **/
void      utiImage1DMinMax(utiImage1D  *ep);

#endif
/******************************************************************************/
/******************************************************************************/
