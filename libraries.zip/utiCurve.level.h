/*  essai/C/utiCurve.level.h                                                  */
/*  Mennessier Gerard                   20010502                              */
/*  Last revised M.G.                   20040330                              */
/*                                                                            */

#ifndef  DEF_UTICURVE_LEVEL_H
#define  DEF_UTICURVE_LEVEL_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiAlloc.h"
#include  "utiMath.type.def.h"
#include  "utiCurve.GC.h"

/******************************************************************************/
/*  lcSeg, lcZrange                                                           */
/******************************************************************************/
typedef struct levelCurveSeg
{ double   x[2];    /** x coord of 2 extremities **/
  double   y[2];    /** y coord of 2 extremities **/
  int      iz;      /** z integer index of the level curve **/
} lcSeg, *lcSegp;

typedef struct levelCurveDiff
{ double   zo;     /** z origin **/
  double   zpa;    /** zpa      **/
  double   zn;     /** z min    **/
  double   zx;     /** z max    **/
  int      in;     /** zn = zo + zpa * in **/
  int      ix;     /** zx = zo + zpa * ix **/
} lcZrange, *lcZrangep;

lcSeg     *lcSegAlloc(size_t  nz,char *prognamp);
lcSeg     *lcSegChkRealloc(lcSeg *p,size_t  *nzp,size_t neednz,size_t incrnz,
                                                                     char *prognamp);
void      lcSegPrint(FILE *bufp,lcSeg *p);
void      lcSegArrayPrint(FILE *bufp,lcSeg *p,size_t n);
void      lcSegZero(lcSeg *p);
void      lcSegCpy1p(lcSeg *sfp,lcSeg *sip);

void      lcZrangeZero(lcZrange *p);
void      lcZrangePrint(FILE *bufp, lcZrange *p);
/******************************************************************************/
/*  lcSegVec                                                                  */
/******************************************************************************/
typedef struct lcSegVec
{ size_t        z;
  size_t        x;
  lcSeg        *p;
  curveGC      *gcp;         /** pointer to associated GC **/
} lcSegVec, *lcSegVecp;

#define   lcSegVecAlloc(nz,prognamp)       (lcSegVec *)myCurveVecAlloc((nz),prognamp)
#define   lcSegVecChkRealloc(p,nzp,needz,inz,pronamp)              \
                            (lcSegVec *)myCurveVecChkRealloc(p,nzp,needz,inz,pronamp)
void      lcSegPVecAlloc(lcSegVec *vecp,size_t  nz);
void      lcSegPVecRealloc(lcSegVec *vecp,size_t neednz,size_t incrnz);
void      lcSegPVecFree(lcSegVec *vecp);
void      lcSegVecFree(lcSegVec *vecp);
void      lcSegVecPrint(FILE  *bufp, lcSegVec *vecp);
void      lcSegVecInc1 (lcSegVec *vecp,lcSeg s);
void      lcSegVecInc1p(lcSegVec *vecp,lcSeg *sp);
void      lcSegVecInc1PointData(lcSegVec *vecp,double *p1p, double *p2p, int iz);
void      lcSegVecInc1CoorData(lcSegVec *vecp,double x0, double y0,
                                                       double x1, double y1, int iz);
void      lcSegVecInc1CoorPData(lcSegVec *vecp,double *xp, double *yp, int iz);


void      lcSegSFromLineInit(double x0, double x1, double *yp, 
                                                     double z0, double z1, double z);
int       lcSegAddSFromLineRectangle(double *xp, size_t nx, double *yp,
                       double *z0p, double *z1p, double z, int iz, lcSegVec *lcsegp);
int       lcSegAddSFromLineTriangle(double *xp, size_t nx, double xi,
                                                              double y0, double y1,
                         double *z0p, double zi, double z, int iz, lcSegVec *lcsegp);
int       lcSegAddS(double *xp, size_t nx, double *yp, size_t ny, 
                                       myBOOL brectangle, int *ixiGeop, int *ixfGeop,
                              double **zfpp,  double z, int iz, lcSegVec *lcsegvecp);

int       lcSegAddMFromLineRectangle(double *xp, size_t nx, double *yp,
                         double *z0p, double *z1p, lcZrange *lcZp, lcSegVec *lcsegp);
int       lcSegAddMFromLineTriangle(double *xp, size_t nx, double xi,
                                                              double y0, double y1,
                           double *z0p, double zi, lcZrange *lcZp, lcSegVec *lcsegp);
int       lcSegAddM(double *xp, size_t nx, double *yp, size_t ny, 
                                       myBOOL brectangle, int *ixiGeop, int *ixfGeop,
                                 double **zfpp, lcZrange *lcZp, lcSegVec *lcsegvecp);

int       lcSegAddSFromQuadrangles(double *x0p, double *x1p, size_t nx, short close,
                                       int *lp, double h, int ih, lcSegVec *lcsegvp);
#endif
/******************************************************************************/
/******************************************************************************/
