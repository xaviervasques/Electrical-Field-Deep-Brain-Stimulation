/*  ../libmy/utiCurve.set.h                                                   */
/*  Mennessier Gerard                   20010502                              */
/*       revised M.G.                   20020904                              */
/*  Last revised M.G.                   20050207                              */
/*                                                                            */

#ifndef  DEF_UTICURVE_SET_H
#define  DEF_UTICURVE_SET_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiAlloc.h"

/******************************************************************************/
/*  cSet                                                                     */
/******************************************************************************/
typedef struct cSet                                                 /** curve set **/
{ void         *p;           /** pointer to  cPoly | cSegVec | lcSegVec **/
  int           type;
} cSet, *cSetp;
/** type has value in MY_CPOLY   | MY_CPOLYV   |
                      MY_CSEGV   | MY_LCSEGV   | MY_CSTRING  | 
                      MY_CCIRCLE | MY_CCIRCLEV | MY_CELLIPSE | MY_CELLIPSEV |
                      MY_CPOINTS                                                  **/

cSet     *cSetAlloc(size_t  nz,char *prognamp);
cSet     *cSetChkRealloc(cSet *p,size_t  *nzp,size_t neednz,size_t incrnz,
                                                                     char *prognamp);
void      cSetPrint(FILE *bufp,cSet *p);
void      cSetArrayPrint(FILE *bufp,cSet *p,size_t n);
void      cSetZero(cSet *p);
void      cSetCpy1p(cSet *sfp,cSet *sip);

/******************************************************************************/
/*  cSetVec                                                                  */
/******************************************************************************/
typedef struct cSetVec
{ size_t        z;
  size_t        x;
  cSet         *p;
} cSetVec, *cSetVecp;

#define   cSetVecAlloc(nz,prognamp)            (cSetVec *)myVecAlloc((nz),prognamp)
#define   cSetVecChkRealloc(p,nzp,needz,inz,pronamp)              \
                                 (cSetVec *)myVecChkRealloc(p,nzp,needz,inz,pronamp)
void      cSetPVecAlloc(cSetVec *vecp,size_t  nz);
void      cSetPVecRealloc(cSetVec *vecp,size_t neednz,size_t incrnz);
void      cSetPVecFree(cSetVec *vecp);
void      cSetVecFree(cSetVec *vecp);
void      cSetVecPrint(FILE  *bufp, cSetVec *vecp);
void      cSetVecInc1(cSetVec *vecp,cSet s);
void      cSetVecInc1p(cSetVec *vecp,cSet *sp);
void      cSetVecInc1ptype(cSetVec *vecp, void *p, int type);
void      cSetVecAddSetVec(cSetVec *vecp, cSetVec *vecnewp);

#endif
/******************************************************************************/
/******************************************************************************/
