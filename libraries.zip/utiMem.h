/*   ..libmy/utiMem.h                                                         */
/*   Mennessier Gerard                  19940822                              */
/*   Last revised M.G.                  20030604                              */

#ifndef  DEF_UTIMEM_H
#define  DEF_UTIMEM_H

#include  <stddef.h>

extern    void     *memChrBack(const void *mp,int c,size_t n);

extern    void     *memChr2(const void *mp,int c1,int c2,int *valuep,size_t n);
extern    void     *memDiffChr(const void *mp,int c,size_t n);
extern    int       memCmp2(const void *,size_t,const void *,size_t);
extern    void     *memCpyP(void *mfp, const void  *mip, size_t n);
extern    int       memEq  (const void *,size_t,const void *,size_t);
extern    int       memGetNextSpe (const void *,size_t,int);
extern    int       memGetNextSpes(const void *,size_t,char *);

extern    long      memAtoL(const void *,size_t);
extern    char     *memAtoLpart(long *sump, const void *mp, size_t n);
extern    size_t    memCpySkipChr(void *mfp, const void  *mip, size_t n, int c);
extern    size_t    memCpySkipStr(void *mfp, const void  *mip, size_t n, char *sp);
extern    size_t    memNormalizeSpace(void *mfp, const void  *mip, size_t n);
extern    void     *memMem(const void *m1p, size_t n1, const void *m2p, size_t n2);

#endif                                                   /** ifndef  DEF_UTIMEM_H **/
/******************************************************************************/
/******************************************************************************/
