/*  URMAE/orientHaut/linear4.GL.V2/gl.linear4.03.glob.h                       */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20030513                                */

#ifndef  DEF_GL_LINEAR4_03_GLOB_H
#define  DEF_GL_LINEAR4_03_GLOB_H

#include  <GL/glut.h>
#include  "utiVecChr.h"

extern    GLfloat   win03ew, win03eh,
                    win030ew, win030eh, win031ew, win031eh, win032ew, win032eh,
                                                                  win033ew, win033eh;

extern    GLfloat   rs03w,  rs03h;
extern    GLfloat   rs030w, rs031w, rs032w, rs033w;
extern    GLfloat   rs030h, rs031h, rs032h, rs033h;
extern    GLfloat   p03w,   p03h;
extern    GLfloat   p030w,  p031w,  p032w,  p033w;
extern    GLfloat   p030h,  p031h,  p032h,  p033h;

extern    chrVec    PSfileNameBaseV;
extern    chrVec    PSfileNameEV;
extern    chrVec    PSfileNameSTV;

extern    char      frameEp[],  frameSp[];
extern    int       framei;

#endif
/******************************************************************************/
/******************************************************************************/
