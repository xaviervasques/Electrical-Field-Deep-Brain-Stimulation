/*  URMAE/orientHaut/linear4.GL.V1/gm.drawstate.threshold.statalloc.h         */
/*  Mennessier Gerard                 20030509                                */
/*  Last Revised : G.M.               20030509                                */

#ifndef  DEF_GM_DRAWSTATE_THRESHOLD_STATALLOC_H
#define  DEF_GM_DRAWSTATE_THRESHOLD_STATALLOC_H

#include  "utiVecChr.h"

                              /** THRESHOLD PARAMETERS **/
static    chrVec    stateThresholdV = {0,0,NULL};
static    double    stateThreshold;

static    chrVec    stateVolumeGlobalV = {0,0,NULL};
static    double    stateVolumeGlobal;

static    chrVec    stateVolumePallidusV = {0,0,NULL};
static    double    stateVolumePallidus;


                              /** CURVES SETS **/


#endif
/******************************************************************************/
/******************************************************************************/
