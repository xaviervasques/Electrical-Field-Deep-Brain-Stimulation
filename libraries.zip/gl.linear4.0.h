/*  URMAE/orientHaut/linear4.GL.V1/gl.linear4.0.h                             */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20020410                                */

#ifndef  DEF_GL_LINEAR4_0_H
#define  DEF_GL_LINEAR4_0_H

void      gmGl0InitWin(void);
void      gmGl0Display(void);
void      gmGl0Reshape(int w, int h);

#endif
/******************************************************************************/
/******************************************************************************/
