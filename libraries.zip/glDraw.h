#ifndef  DEF_GLDRAW_H
#define  DEF_GLDRAW_H

void      glInit();
void      renderBitmapString(float x, float y, void *fontchoice, char *string);

void      display(void);
void      reshape(int w, int h);
void      keyboard(unsigned char key, int x, int y);
void      move(int key, int x, int y);

#endif
/******************************************************************************/
/******************************************************************************/
