#ifndef  DEF_DATAFILE_H
#define  DEF_DATAFILE_H

int       dataFileRead(char *fileNamp);
int       dataTranslate();
void      StereoPoint();

#endif
/******************************************************************************/
/******************************************************************************/
