/*  libc/recipe2double/recipe.amotry.h                                        */
/*  Last Revised : G.M.               20030522                                */

/** VECTOR and MATRIX INDICES FROM 0 to DIM-1                                **/
/** VECTOR and MATRIX : DOUBLE version                                       **/

#ifndef  DEF_AMOTRY_H
#define  DEF_AMOTRY_H

double    amotry(double **p, double y[], double psum[], int ndim,
                                     double (*funk)(double []), int ihi, double fac);

#endif
/******************************************************************************/
/******************************************************************************/
