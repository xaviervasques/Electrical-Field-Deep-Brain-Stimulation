/*  libc/libmy/utiMath.macro.undef.h                                          */
/*  Mennessier Gerard                 20030618                                */
/*  Last Revised : G.M.               20030618                                */

#ifndef  DEF_UTIMATH_MACRO_UNDEF_H
#define  DEF_UTIMATH_MACRO_UNDEF_H

#undef   mySWAP
#undef   myMAX
#undef   myMIN
#undef   myFLOORi
#undef   myCEILi

#endif
/******************************************************************************/
/******************************************************************************/
