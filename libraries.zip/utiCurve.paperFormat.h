/*  utiCurve.paperFormat.h                                                    */
/*  Mennessier Gerard                   20020103                              */
/*  Last revised M.G.                   20020103                              */
/*                                                                            */

#ifndef  DEF_UTICURVE_PAPERFORMAT_H
#define  DEF_UTICURVE_PAPERFORMAT_H

#define  A4W_    210.
#define  A4H_    297.

#endif
/******************************************************************************/
/******************************************************************************/
