/*  URMAE/orientHaut/linear4.GL.V2/gm.drawstate.threshold.h                   */
/*  Mennessier Gerard                 20030509                                */
/*  Last Revised : G.M.               20030512                                */

#ifndef  DEF_GM_DRAWSTATE_THRESHOLD_H
#define  DEF_GM_DRAWSTATE_THRESHOLD_H

#include  <stddef.h>
#include  "utistdIO.h"


#include  "utiVecChr.h"
#include  "utiCurve.def.h"
#include  "utiCurve.set.h"

void      gmDrawStateThresholdInit();
void      gmDrawStateThresholdSet(chrVec *thresholdVp);

chrVec   *gmDrawStateGetThreshold();
chrVec   *gmDrawStateGetVolumeGlobal();
chrVec   *gmDrawStateGetVolumePallidus();

#endif
/******************************************************************************/
/******************************************************************************/
