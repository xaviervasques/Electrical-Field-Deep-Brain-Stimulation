/*  ../libmy/utiClassRangeInt.h                                               */
/*  Mennessier Gerard                   940810                                */
/*  Last Revised              M.G.      970421                                */

#ifndef   UTICLASSRANGEINT_H
#define   UTICLASSRANGEINT_H

#include  <stddef.h>

void      ranindInt(int *xp,int *indp,size_t nz);
int       classInt(int *indexp,int x,int *xp,size_t nx);

#endif
/******************************************************************************/
