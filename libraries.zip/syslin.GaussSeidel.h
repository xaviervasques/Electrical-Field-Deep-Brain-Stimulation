/*  ../myGauss/syslin.GaussSeidel.h                                           */
/*                                                                            */

#ifndef  DEF_SYSLIN_GAUSS_SEIDEL_H
#define  DEF_SYSLIN_GAUSS_SEIDEL_H

void      sl_gauss_seidel(size_t n, double *ap, double *bp, double *x1p,
		                           int iterx, double **tpp, double eps);

#endif
/******************************************************************************/
/******************************************************************************/
