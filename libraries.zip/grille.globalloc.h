#ifndef  DEF_GRILLE_GLOBALLOC_H
#define  DEF_GRILLE_GLOBALLOC_H

#include  "utiVecDbl.h"


size_t    grilleSizep[3] = {50, 50, 50};
size_t    TailleX, TailleY, TailleZ;

double    grilleSizeM1dp[3];

double    grilleDimensiondp[3];

dblVec    grilleValuesVec = {0, 0, NULL};
double   *grilleValuesp;
double  **grilleValuespp;

double    IsoLeveld = 1.0;

#endif
/******************************************************************************/
/******************************************************************************/
