/*  bio_phys/URMAE/numerical/linearGL4/gl.linear4.01.globalloc.h              */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20030509                                */

#ifndef  DEF_GL_LINEAR4_01_GLOBALLOC_H
#define  DEF_GL_LINEAR4_01_GLOBALLOC_H

#include  <GL/glut.h>
#include  "utiVecChr.h"

/*
  0       ConsoleRoot
  01      Caracteristiques electriques
  010     Pin modes
  011     Voltage
  012     Impedance
  013     Menu OK/CANCEL 
*/

/* Console Window */
/* Electrical Parameters */

GLfloat   win01ew, win01eh,
          win010ew, win010eh, win011ew, win011eh, win012ew, win012eh,
                                                                  win013ew, win013eh;

GLfloat   rs01w  = 1.0,    rs01h  = 0.20;
GLfloat   rs010w = 0.3,    rs011w = 0.3,    rs012w = 0.3,    rs013w = 0.1;
GLfloat   rs010h = 0.6666, rs011h = 0.6666, rs012h = 0.6666, rs013h = 0.6666;
                        /** p011w = p010w + rs010w; p012w = p011w + rs011w;  ...  **/
GLfloat   p01w   = 0.0,    p01h = .20;
GLfloat   p010w  = 0.0,    p011w = 0.3,     p012w = 0.6,     p013w = 0.9;
GLfloat   p010h  = 0.3,    p011h = 0.3,     p012h = 0.3,     p013h = 0.3;

chrVec    pinModV = {0,0,NULL},                               /** current pinMode **/
          newPinModV = {0,0,NULL},
          voltageV = {0,0,NULL},
          newVoltageV = {0,0,NULL},                           /** current voltage **/
          crZV = {0,0,NULL},                                /** current impedance **/
          msZV = {0,0,NULL};                               /** measured impedance **/

char      predictedImpedancestrp[12] = "5000.0",  *measuredImpedancestrp ;
char      defaultImpedancestrp[12]   = "5000.0",  *impedancestrp ;

double    impedance,
          predictedImpedance = 5000.0, 
          measuredImpedance  = 1000.0,
          defaultImpedance   = 5000.0;

double    kappaEff;

#endif
/******************************************************************************/
/******************************************************************************/
