/*  bio_phys/URMAE/numerical/xxxx/pot_funcBasis.def.h                         */
/*  Mennessier Gerard                 20000415                                */
/*  Last Revised : G.M.               20000609                                */

#ifndef  DEF_POT_FUNCBASIS_DEF_H
#define  DEF_POT_FUNCBASIS_DEF_H

#define   NORDER_      2
#define   NCOEF_      (NORDER_ + 1)
#define   NINFINITYX_  2

#endif
/******************************************************************************/
/******************************************************************************/
