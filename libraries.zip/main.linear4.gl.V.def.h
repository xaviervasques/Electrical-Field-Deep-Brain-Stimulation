/*  URMAE/orientHaut/linear4.GL.V4/main.linear4.gl.V.def.h                    */
/*  Mennessier Gerard                   20011011                              */
/*  Last Revised : G.M.                 20020430                              */

#ifndef  DEF_MAIN_LINEAR4_GL_V_DEF_H
#define  DEF_MAIN_LINEAR4_GL_V_DEF_H



void       mainpara(int argxi, char *argvpp[]);

#endif
/******************************************************************************/
/******************************************************************************/
