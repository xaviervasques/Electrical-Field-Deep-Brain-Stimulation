/*  .../orientHaut/linear4.Common.V1/gridZ.linear4.delta.def.h                */
/*  Mennessier Gerard                 20020404                                */
/*  Last Revised : G.M.               20020404                                */

#ifndef  DEF_GRIDZ_LINEAR4_DELTA_DEF_H
#define  DEF_GRIDZ_LINEAR4_DELTA_DEF_H

#define   MYDELTAZMN_  10
#define   MYDELTAZN_   (1 + 2 * MYDELTAZMN_)

#endif
/******************************************************************************/
/******************************************************************************/
