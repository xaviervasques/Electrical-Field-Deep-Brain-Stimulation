/*  essai/C/utiCurve.poly.h                                                   */
/*  Mennessier Gerard                   20010502                              */
/*  Last revised M.G.                   20030625                              */
/*                                                                            */

#ifndef  DEF_UTICURVE_POLY_H
#define  DEF_UTICURVE_POLY_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiAlloc.h"
#include  "utiMath.type.def.h"
#include  "utiCurve.GC.h"
#include  "utiCurve.Vec.h"

/******************************************************************************/
/*  cPoly : polyline                                                          */
/******************************************************************************/
typedef struct cPoly 
{ size_t        z;           /** allocated size for xp and yp **/
  size_t        x;           /** effective extremity number **/
  double       *xp;          /** x coord of extremities **/
  double       *yp;          /** y coord of extremities **/
  curveGC      *gcp;         /** pointer to associated GC **/
  myBOOL        closed;      /** if TRUE, close the polyline **/
} cPoly, *cPolyp;

cPoly    *cPolyAlloc(size_t  nz,char *prognamp);
cPoly    *cPolyChkRealloc(cPoly *p,size_t  *nzp,size_t neednz,size_t incrnz,
                                                                     char *prognamp);
void      cPolyPrint(FILE *bufp, cPoly *p);
void      cPolyZero(cPoly *p);
void      cPolyCopyp(cPoly *pf, cPoly cc);
void      cPolyCopypp(cPoly *pf, cPoly *pi);

void      cPolyPAlloc(cPoly *p,size_t  nz);
void      cPolyPRealloc(cPoly *p,size_t neednz,size_t incrnz);
void      cPolyPFree(cPoly *p);
void      cPolyPPrint(FILE  *bufp, cPoly *p);
void      cPolyPInc1(cPoly *p,double x, double y);
void      cPolyPInc1p(cPoly *p,double xyp[2]);             /** x=xyp[0], y=xyp[1] **/
void      cPolyPIncN(cPoly *p,double *xp, double *yp, size_t n);

/******************************************************************************/
/*  cPolyVec                                                                  */
/******************************************************************************/
typedef struct cPolyVec
{ size_t        z;
  size_t        x;
  cPoly        *p;
  curveGC      *gcp;         /** pointer to associated GC **/
} cPolyVec, *cPolyVecp;

#define   cPolyVecAlloc(nz,prognamp)       (cPolyVec *)myCurveVecAlloc((nz),prognamp)
#define   cPolyVecChkRealloc(p,nzp,needz,inz,pronamp)              \
                            (cPolyVec *)myCurveVecChkRealloc(p,nzp,needz,inz,pronamp)
void      cPolyPVecAlloc(cPolyVec *vecp,size_t  nz);
void      cPolyPVecRealloc(cPolyVec *vecp,size_t neednz,size_t incrnz);
void      cPolyPVecFree(cPolyVec *vecp);
void      cPolyVecFree(cPolyVec *vecp);
void      cPolyVecPrint(FILE *bufp, cPolyVec *p);
void      cPolyPVecPrint(FILE *bufp, cPolyVec *vecp);

#endif
/******************************************************************************/
/******************************************************************************/
