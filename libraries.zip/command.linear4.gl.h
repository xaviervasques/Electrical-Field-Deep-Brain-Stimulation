/*  URMAE/orientHaut/linear4.GL.V1/command.linear4.gl.h                       */
/*  Mennessier Gerard                 20010507                                */
/*  Last Revised : G.M.               20020430                                */

#ifndef   DEF_COMMAND_LINEAR4_GL_H
#define   DEF_COMMAND_LINEAR4_GL_H

#include  <stddef.h>
#include  "utistdIO.h"

void      commandLine_linear_gl(FILE **bufpp, char **fileNamepp,
                              char *newpinmodstrp, char *newneckmodstrp, int *bip,
                                                             int argx, char *argv[]);
void      nameWritePSsetPinmod(char *nameWritePSp, char *newPinmodesp);
void      nameWritePSsetObs(char *nameWritePSp, char *newObsp);

#endif
/******************************************************************************/
/******************************************************************************/

