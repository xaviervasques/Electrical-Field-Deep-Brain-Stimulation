/*  essai/C/utiCurve.GC.h                                                     */
/*  Mennessier Gerard                   20010502                              */
/*  Last revised M.G.                   20010808                              */
/*                                                                            */

#ifndef  DEF_UTICURVE_GC_H
#define  DEF_UTICURVE_GC_H

#include  <stddef.h>

/******************************************************************************/
/*   curveGC                                                                  */
/******************************************************************************/
typedef struct curveGC                            /** Graphic Context/Information **/
{ int           lineWidth;   /** in pixel **/
  float         color[3];    /** R G B in range [0. , 1.] **/
} curveGC, *curveGCp;

#endif
/******************************************************************************/
/******************************************************************************/
