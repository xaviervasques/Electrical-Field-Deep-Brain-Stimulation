/*  URMAE/numerical/linear4/eltrdPot.linear4.h                                */
/*  Mennessier Gerard                 20010518                                */
/*  Last Revised : G.M.               20010612                                */

#ifndef  DEF_ELTRDPOT_LINEAR4_H
#define  DEF_ELTRDPOT_LINEAR4_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiAlloc.h"

#include  "eltrd.def.h"
#include  "pot_funcBasis.def.h"                                    /** for NCOEF_ **/

/**
  sorderp[is] = order at pinExtremity is;
  scoefpp[is][0, 1, ..., sorder[is]+1 ]
              = values of the corresponding coefficients

  pinModp[i] = 0 if V is fixed
             = 1 if V is variable, et should be optimised
**/

typedef struct gmEltrdPot
{ double        scoefmatp[NPEX_ * NCOEF_];            /** coefs at pinExtremities **/
  double       *scoefpp[NPEX_];
  int           sorderp[NPEX_];                       /** order at pinExtremities **/
  int           scoefx;                 /** number of coefs = SUM(sorderp[i] + 1) **/

  int           pinModp[NPX_];                                       /** pin mode **/
  int           pinVarX;                     /** number of variable pin potential **/

  double        pinVp[NPX_];                                    /** pin potential **/
  double        pinIp[NPX_];                                    /** pin intensity **/
  double        power;                           /**  power (with unit KAPPA ~ 1) **/
  double        effI;                                     /** efficient intensity **/
} gmEltrdPot, *gmEltrdPotp;

void      gmEltrdPotZero(gmEltrdPot *p);
void      gmEltrdPotPrint(FILE *bufOut, gmEltrdPot *p);
void      gmEltrdPotWrite(FILE *bufOut, gmEltrdPot *p);
void      gmEltrdPotRead(FILE *bufReadp, gmEltrdPot *p);
void      gmEltrdPotSetSCoef(gmEltrdPot *p, double **scoefpp, int *sorderp);
void      gmEltrdPotSetModes(gmEltrdPot *p, int *modp);
void      gmEltrdPotSetV(gmEltrdPot *p, double *vp);
void      gmEltrdPotSetI(gmEltrdPot *p, double *ip);
void      gmEltrdPotCpy(gmEltrdPot *pf, gmEltrdPot *pi);
int       gmBiFromPinV(double *pinVp);
int       gmBiFromStrMod(int *pinmodip, char *pinmodstrp);
double    getDiffPot(double  *pinVp, double neckV);

#endif
/******************************************************************************/
/******************************************************************************/
