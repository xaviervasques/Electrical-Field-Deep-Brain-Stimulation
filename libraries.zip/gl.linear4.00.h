/*  bio_phys/URMAE/numerical/linearGL4/gl.linear4.00.h                        */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20010809                                */

#ifndef  DEF_GL_LINEAR4_00_H
#define  DEF_GL_LINEAR4_00_H

void      gmGl00InitWin(void);
void      gmGl00Display(void);
void      gmGl00Reshape(int w, int h);

void      gmGl000InitWin(void);
void      gmGl000Display(void);
void      gmGl000Reshape(int w, int h);
void      gmGl000KB(unsigned char key, int x, int y);

void      gmGl001InitWin(void);
void      gmGl001Display(void);
void      gmGl001Reshape(int w, int h);
void      gmGl001MN(int menuindex);
void      gmGl001MN1(void);
void      gmGl001MN2(void);

#endif
/******************************************************************************/
/******************************************************************************/
