/*  libc/libmy/utiMath.type.def.h                                             */
/*  Mennessier Gerard                 20000414                                */
/*  Last Revised : G.M.               20030618                                */

#ifndef  DEF_UTIMATH_TYPE_DEF_H
#define  DEF_UTIMATH_TYPE_DEF_H

#ifndef   myBOOL_defined
typedef   short     myBOOL;
#define   myFALSE   0
#define   myTRUE    1
#define   myBOOL_defined
#endif


#endif
/******************************************************************************/
/******************************************************************************/
