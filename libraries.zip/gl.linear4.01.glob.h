/*  bio_phys/URMAE/numerical/linearGL4/gl.linear4.01.glob.h                   */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20010827                                */

#ifndef  DEF_GL_LINEAR4_01_GLOB_H
#define  DEF_GL_LINEAR4_01_GLOB_H

#include  <GL/glut.h>
#include  "utiVecChr.h"

/* Console Window */
/* Electrical Parameters */

extern    GLfloat   win01ew, win01eh,
                    win010ew, win010eh, win011ew, win011eh, win012ew, win012eh,
                                                                  win013ew, win013eh;

extern    GLfloat   rs01w, rs01h;
extern    GLfloat   rs010w, rs011w, rs012w, rs013w;
extern    GLfloat   rs010h, rs011h, rs012h, rs013h;
extern    GLfloat   p01w, p01h;
extern    GLfloat   p010w, p011w, p012w, p013w;
extern    GLfloat   p010h, p011h, p012h, p013h;

extern    chrVec    pinModV,
                    newPinModV,
                    voltageV,
                    newVoltageV,
                    crZV,
                    msZV;

extern    char      predictedImpedancestrp[],  *measuredImpedancestrp;
extern    char      defaultImpedancestrp[],    *impedancestrp ;

extern    double    impedance,
                    predictedImpedance,
                    measuredImpedance,
                    defaultImpedance;

#endif
/******************************************************************************/
/******************************************************************************/
