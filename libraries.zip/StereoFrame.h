#ifndef  STEREOFRAME_H 
#define  STEREOFRAME_H

void StereoFrame();

#endif
 
