

#ifndef  DEF_GRILLE_H
#define  DEF_GRILLE_H

void      grilleSetDim(double dimen);
void      grilleSetSizes(int sizeX, int sizeY, int sizeZ);
void      grilleIndex2Phys(double *posPhysp, int *posIndexp);
void      grilleValues();


#endif
/******************************************************************************/
/******************************************************************************/
