/*  ../libmy/utiImage2D.h                                                     */
/*  Mennessier Gerard                   20031007                              */
/*  Last revised M.G.                   20040428                              */

#ifndef  DEF_UTIIMAGE2D_H
#define  DEF_UTIIMAGE2D_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiVecChr.h"
#include  "utiImage0D.h"

/******************************************************************************/
typedef struct  utiImage2D
{ utiImage0D   im0D;
  chrVec       dataV;
  size_t  wbz;            /** allocated BYTE size per row ( >= wpx*bytesPerPixel) **/
  size_t  wpx;                                    /** width, PIXEL number per row **/
  size_t  hpx;                                         /** height, number of rows **/
  unsigned int  graymin;                                   /** minimum gray value **/
  unsigned int  graymax;                                   /** maximum gray value **/
} utiImage2D, *utiImage2Dp;

/******************************************************************************/

void      utiImage2DdataPVecAlloc(utiImage2D *ep, size_t nz);
void      utiImage2DdataPVecRealloc(utiImage2D *ep, size_t neednz, size_t incrnz);
void      utiImage2DdataPVecFree(utiImage2D *ep);
void      utiImage2DZero(utiImage2D *ep);

void      utiImage2DdataBytesPrint(FILE *streamp, utiImage2D *ep);
void      utiImage2DPrint(FILE *streamp, utiImage2D *ep);

void      utiImage2DSetAll(utiImage2D *ep, unsigned char *inkip);
void      utiImage2DSet1(utiImage2D *ep, unsigned char *inkip, int ix,int iy);

              /** Relevant ONLY when pixels are ushort GRAY LEVELS (or luminance) **/
void      utiImage2DMinMax(utiImage2D  *ep);

#endif
/******************************************************************************/
/******************************************************************************/
