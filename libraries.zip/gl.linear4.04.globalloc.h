/*  bio_phys/URMAE/numerical/linearGL4/gl.linear4.01.globalloc.h              */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20030512                                */

#ifndef  DEF_GL_LINEAR4_04_GLOBALLOC_H
#define  DEF_GL_LINEAR4_04_GLOBALLOC_H

#include  <GL/glut.h>
#include  "utiVecChr.h"

/*
  0       ConsoleRoot
  04      Caracteristiques du seuil
  010     Titre
  011     Seuil
  012     Volumes au dessus du seuil
  013     Menu OK/CANCEL 
*/

/* Console Window */
/* Threshold Parameters */

GLfloat   win04ew, win04eh,
          win040ew, win040eh, win041ew, win041eh, win042ew, win042eh,
                                                                  win043ew, win043eh;

GLfloat   rs04w  = 1.0,    rs04h  = 0.20;
GLfloat   rs040w = 0.2,    rs041w = 0.25,    rs042w = 0.45,    rs043w = 0.1;
GLfloat   rs040h = 0.6666, rs041h = 0.6666, rs042h = 0.6666, rs043h = 0.6666;
                        /** p041w = p040w + rs040w; p042w = p041w + rs041w;  ...  **/
GLfloat   p04w   = 0.0,    p04h = .80;
GLfloat   p040w  = 0.0,    p041w = 0.2,     p042w = 0.45,    p043w = 0.9;
GLfloat   p040h  = 0.3,    p041h = 0.3,     p042h = 0.3,     p043h = 0.3;


chrVec    thresholdV = {0,0,NULL},                          /** current Threshold **/
          newThresholdV = {0,0,NULL},                           /** new Threshold **/
          volumeGlobalV = {0,0,NULL},                   /** current Volume Global **/
          volumePallidusV = {0,0,NULL}; /** current Volume restricted to Pallidus **/

double    threshold = 1.0,
          volumeGlobal = 0.0,
          volumePallidus = 0.0;

char      defaultThresholdstrp[] = "200.0";

#endif
/******************************************************************************/
/******************************************************************************/
