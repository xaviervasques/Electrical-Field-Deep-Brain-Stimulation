/*  ../libmy/utiVecUInt.h                                                     */
/*  Mennessier Gerard                   20030926                              */
/*  Last revised : M.G.                 20030926                              */

#ifndef  DEF_UTIVECUINT_H
#define  DEF_UTIVECUINT_H

#include  <stddef.h>
#include  "utistdIO.h"

typedef struct uintVec
{ size_t         z;
  size_t         x;
  unsigned int  *p;
} uintVec, *uintVecp;

#define  uintVecAlloc(nz,prognamp)            (uintVec *)myVecAlloc((nz),prognamp)
#define  uintVecChkRealloc(p,nzp,needz,inz,pronamp)              \
                              (uintVec *)myVecChkRealloc(p,nzp,needz,inz,pronamp)
/* extern    uintVec   *uintVecAlloc   (size_t nz, char *prognamp); */
extern    void      uintPVecAlloc  (uintVec *vecp, size_t nz);
extern    void      uintPVecRealloc(uintVec *vecp, size_t neednz, size_t incrnz);
extern    void      uintPVecFree   (uintVec *vecp);
extern    void      uintVecFree    (uintVec *vecp);
extern    void      uintVecPrint   (FILE  *bufp, uintVec *vecp);
extern    void      uintVecInc1    (uintVec *vecp, unsigned int y);
extern    void      uintVecIncN    (uintVec *vecp, unsigned int *yp,size_t n);

#endif
/******************************************************************************/
/******************************************************************************/
