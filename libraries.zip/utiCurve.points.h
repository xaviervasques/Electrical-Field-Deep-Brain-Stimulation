/*  ../libmy/utiCurve.points.h                                                */
/*  Mennessier Gerard                   20050207                              */
/*  Last revised M.G.                   20050208                              */
/*                                                                            */
 
#ifndef  DEF_UTICURVE_POINT_H
#define  DEF_UTICURVE_POINT_H
 
#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiAlloc.h"
#include  "utiCurve.GC.h"

/******************************************************************************/
/*  cPoints : set of points                                                   */
/******************************************************************************/
typedef struct cPoints                                                 /** points **/
{ size_t        z;           /** allocated number of points ==> xp size = 2*z **/
  size_t        x;           /** effective number of points <= z **/
  double       *xp;          /** coord ofpoints : x0,y0, x1,y1, x2,y2 **/
  curveGC      *gcp;         /** pointer to associated GC **/
} cPoints, *cPointsp;
 
void      cPointsPAlloc(cPoints *p, size_t nz, char *progcallp);
void      cPointsPRealloc(cPoints *p, size_t neednz, size_t incrnz, char *progcallp);
void      cPointsPrint(FILE  *bufp, cPoints *p);
void      cPointsInc1(cPoints *p, double x, double y);
void      cPointsIncNp(cPoints *p, size_t n, double *xyp);

#endif
/******************************************************************************/
/******************************************************************************/
