#ifndef DEF_FIELD_H 
#define DEF_FIELD_H 

double    fcercle(double currentx,double currenty,double rayon);
void      Intersection();
int       numbermin(float tab[][3], double min, int Np);
double    minvalue(float tab[][3]);
void      IsoField(double theta, double phi);
void      VolumeChamps(double theta, double phi);
void      InterVolumeFile(double theta, double phi);
void      InterSurfaceValue(double theta, double phi);
void      InterSurfacePoint(double theta, double phi);


#endif 
