/*  URMAE/numerical/linear4/gridR.linear4.h                                   */
/*  Mennessier Gerard                 20000414                                */
/*  Last Revised : G.M.               20010618                                */

#ifndef  DEF_GRIDR_LINEAR4_H
#define  DEF_GRIDR_LINEAR4_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiAlloc.h"

typedef struct gmGridRStruct
{ char     *unitnamep;
  double   *rhotndp;                            /** nodes, rhot(ilda) coordinates **/
  double   *rhondp;                                    /** nodes, rho coordinates **/
  size_t    rhotndz;
  size_t    rhotndx;
  double   *rhotllp;                                         /** rho-link lengths **/
  size_t    rhotllz;
  size_t    rhotllx;
  double    eltrdR;
  int       eltrdRhondI;
  int       eltrdRhollI;
  double    rhotndMAX;
  double    rhondMAX;
  double    neckRho;
  int       neckIndx;                                  /** last rho index of neck **/
  int       cylcond;    /** -1 full insulator, 0 neck conductor, 1 full conductor **/
  int       cylgeom;                              /** 0 without neck, 1 with neck **/
} gmGridR, *gmGridRp;

gmGridR  *gmGridRAlloc (size_t nz, char *progcallp);
void      gmGridRPAlloc(size_t llz, gmGridR *p);
int       gmGridRinit (FILE *bufOut, gmGridR *p, double *inforpap, int cylcond);
void      gmGridRprint(FILE *bufOut, gmGridR *p);
void      gmGridRCpy(char *unitp, double scale, gmGridR *pf, gmGridR *pi);
int       gmGridRreadINI(FILE *bufGridRinitp, double *inforpap, int *cylcondp);

#endif
/******************************************************************************/
/******************************************************************************/
