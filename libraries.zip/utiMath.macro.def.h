/*  libc/libmy/utiMath.macro.def.h                                            */
/*  Mennessier Gerard                 20030618                                */
/*  Last Revised : G.M.               20030618                                */

#ifndef  DEF_UTIMATH_MACRO_DEF_H
#define  DEF_UTIMATH_MACRO_DEF_H

#define   mySWAP( X, Y, BAN)                               \
          ( BAN = X,  X = Y, Y = BAN)

#define   myMAX(X , Y)                                     \
          ( (X) >= (Y)? (X) : (Y) )

#define   myMIN(X , Y)                                     \
          ( (X) <= (Y)? (X) : (Y) )

#define   myFLOORi(X)                                      \
          ( (X) >= 0?  (int)(X) : (int)(X) - 1 )

#define   myCEILi(X)                                       \
          ( (X) > 0?  (int)(X) + 1 : (int)(X) )

#endif
/******************************************************************************/
/******************************************************************************/
