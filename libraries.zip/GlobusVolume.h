/** Xavier Vasques 01/06/2006      **/
/** Last Revised X.V. : 21/12/2006 **/

#ifndef DEF_GLOBUSVOLUME_H
#define DEF_GLOBUSVOLUME_H

void      GlobusVolume();
double    droite(double x, double y);

#endif
