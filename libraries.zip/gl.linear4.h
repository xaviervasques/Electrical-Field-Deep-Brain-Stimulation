/*  URMAE/orientHaut/linear4.GL.V1/gl.linear4.h                               */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20020410                                */

#ifndef  DEF_GL_LINEAR4_H
#define  DEF_GL_LINEAR4_H

#include  <GL/glut.h>
#include  "utiVecChr.h"

void      gmGlInitGlut(int *argxp,char *argvpp[]);

int       gmGlStrokeStrSize(void *font, char *cp);
int       gmGlStrokeStrDraw(void *font, char *cp);
void      gmGlKeyboardChrV(chrVec *vp, unsigned char key);

#endif
/******************************************************************************/
/******************************************************************************/
