/*  bio_phys/URMAE/numerical/linearGL4/gl.linear4.00.glob.h                   */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20010827                                */

#ifndef  DEF_GL_LINEAR4_00_GLOB_H
#define  DEF_GL_LINEAR4_00_GLOB_H

#include  <GL/glut.h>
#include  "utiVecChr.h"

extern    GLfloat   win00ew, win00eh,
                    win000ew, win000eh, win001ew, win001eh;

extern    GLfloat   rs00w, rs00h,
                    rs000w, rs000h, rs001w, rs001h;
extern    GLfloat   p00w, p00h;
extern    GLfloat   p000w, p001w;
extern    GLfloat   p000h, p001h;

extern    chrVec    patientNameV,
                    newPatientNameV;
extern    GLfloat   patientNameWidthF;

#endif
/******************************************************************************/
/******************************************************************************/
