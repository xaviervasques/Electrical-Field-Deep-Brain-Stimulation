/*  essai/C/utiCurve.2PS.h                                                    */
/*  Mennessier Gerard                   20010502                              */
/*  Last revised M.G.                   20030626                              */
/*                                                                            */

#ifndef  DEF_UTICURVE_2PS_H
#define  DEF_UTICURVE_2PS_H

#include  <stddef.h>
#include  <math.h>
#include  "utistdIO.h"
#include  "utiCurve.circle.h"
#include  "utiCurve.ellipse.h"
#include  "utiCurve.level.h"
#include  "utiCurve.poly.h"
#include  "utiCurve.seg.h"
#include  "utiCurve.string.h"
#include  "utiCurve.set.h"

/******************************************************************************/
void      PSgraphInit(FILE *psfile);
void      PSgraphPageInit(FILE *psfile);
void      PSgraphPageEnd(FILE *psfile);
void      PSgraphEnd(FILE *psfile);
void      PSgraphSetInitCTM(FILE *psfile, double xnx[2], double ynx[2]);
void      PSgraphSetInitPortCTM(FILE *psfile, double xnx[2], double ynx[2]);
void      PSgraphSetInitLandCTM(FILE *psfile, double xnx[2], double ynx[2]);

void      PSgraphSet    (FILE *psfile, cSetVec *setvecp);

void      PSgraphPoly   (FILE *psfile, cPoly *segvecp);
void      PSgraphPolyV  (FILE *psfile, cPolyVec *vecp);
void      PSgraphSegV   (FILE *psfile, cSegVec *segvecp);
void      PSgraphLcSeg  (FILE *psfile, lcSegVec *segvecp);
void      PSgraphStr    (FILE *psfile, cStrVec *strvecp);
void      PSgraphCircle (FILE *psfile, cCircle *p, curveGC *vgcp);
void      PSgraphCircleV(FILE *psfile, cCircleVec *vecp);
void      PSgraphEllipse(FILE *psfile, cEllipse  *p, curveGC *vgcp);
void      PSgraphEllipseV(FILE *psfile, cEllipseVec *vecp);

#endif
/******************************************************************************/
/******************************************************************************/
