/*  URMAE/reconstruction.GM/V1/syslin.LU.h                                    */
/*  Mennessier Gerard                 20060321                                */
/*  Last Revised : G.M.               20060325                                */
/*                                                                            */

#ifndef  DEF_SYSLIN_LU_H
#define  DEF_SYSLIN_LU_H

#include  <stddef.h>
#include  <stdio.h>

void      sl_LU(size_t n, double *bp, double *xp);

#endif
/******************************************************************************/
/******************************************************************************/
