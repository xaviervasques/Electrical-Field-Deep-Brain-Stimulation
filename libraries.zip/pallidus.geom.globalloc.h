/*  URMAE/orientHaut/linear4.GL.V1/pallidus.geom.globalloc.h                  */
/*  Mennessier Gerard                 20010703                                */
/*  Last Revised : G.M.               20020410                                */

#ifndef  DEF_PALLIDUS_GEOM_GLOBALLOC_H
#define  DEF_PALLIDUS_GEOM_GLOBALLOC_H

#include  "utiVecDbl.h"
#include  "utiVecInt.h"

intVec    eltrdPinIndVi = {0,0,NULL};                   /** pin indices **/
dblVec    eltrdSPosVd = {0,0,NULL};    /** ScannerFrame electrode coord **/

                              /** READ DATA **/
                                                  /** ScannerFrame pallidus coord **/
                             /** number of pallidus boundary points in each plane **/
intVec    pallidusNptPlaneDataVi = {0,0,NULL};
intVec    pallidusPosDataVi = {0,0,NULL};
                                                             /** AFTER plane SORT **/
intVec    pallidusNptPlaneVi = {0,0,NULL};
dblVec    pallidusSPosVd = {0,0,NULL};
                                                             /** AFTER angle SORT **/
dblVec    pallidusSsortedPosVd = {0,0,NULL};

double    eltrdSOrip[3];                 /** ScannerFrame: electrode center coord **/
double    eltrdSVecp[3];               /** ScannerFrame: electrode unit direction **/
double    ctheta, stheta, thetaRad, thetaDeg,  cphi, sphi, phiRad, phiDeg;
                                                         /** rotation matrix S->E **/
double    S2E0p[3], S2E1p[3], S2E2p[3];
double   *S2Epp[3] = {S2E0p, S2E1p, S2E2p};
                                                        /** rotation matrix E->ST **/
double    E2ST0p[3], E2ST1p[3], E2ST2p[3];
double   *E2STpp[3] = {E2ST0p, E2ST1p, E2ST2p};

                              /** SCANNER (TRANSLATED) FRAME **/
                                         /** ScannerFrame pallidus boundary coord **/
                                 /** reconstructed from data. May have more points**/
dblVec    pallidusSTBoundVd = {0,0,NULL};

            /** ScannerFrame boundary after rotation around Oz scanner translated **/
dblVec    pallidusSTBoundRotatedVd = {0,0,NULL};

                              /** ELECTRODE FRAME **/
                                       /** ElectrodeFrame pallidus boundary coord **/
dblVec    pallidusEBoundVd = {0,0,NULL};
                                                 
   /** ElectrodeFrame boundary coord after final psi rotation around Oz electrode **/
dblVec    pallidusEBoundRotatedVd = {0,0,NULL};

/* dblVec    pallidusEQuadrVd = {0,0,NULL}; */

#endif
/******************************************************************************/
/******************************************************************************/
