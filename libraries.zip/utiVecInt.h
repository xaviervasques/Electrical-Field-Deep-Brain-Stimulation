/*  ../libmy/utiVecInt.h                                                      */
/*  Mennessier Gerard                   940822                                */
/*  Last revised              M.G.      970505                                */

#ifndef  DEF_UTIVECINT_H
#define  DEF_UTIVECINT_H

#include  <stddef.h>
#include  "utistdIO.h"

typedef struct intVec
{ size_t        z;
  size_t        x;
  int          *p;
} intVec, *intVecp;

#define  intVecAlloc(nz,prognamp)            (intVec *)myVecAlloc((nz),prognamp)
#define  intVecChkRealloc(p,nzp,needz,inz,pronamp)              \
                              (intVec *)myVecChkRealloc(p,nzp,needz,inz,pronamp)
/* extern    intVec   *intVecAlloc   (size_t nz, char *prognamp); */
extern    void      intPVecAlloc  (intVec *vecp,size_t  nz);
extern    void      intPVecRealloc(intVec *vecp,size_t neednz,size_t incrnz);
extern    void      intPVecFree   (intVec *vecp);
extern    void      intVecFree    (intVec *vecp);
extern    void      intVecPrint   (FILE  *bufp,intVec *vecp);
extern    void      intVecInc1    (intVec *vecp,int y);
extern    void      intVecIncN    (intVec *vecp,int *yp,size_t n);

#endif
/******************************************************************************/
/******************************************************************************/
