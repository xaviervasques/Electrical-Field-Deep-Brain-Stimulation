#ifndef  DEF_MARCHCUBE_GLOB_H
#define  DEF_MARCHCUBE_GLOB_H

#include  "marchCube.h"

extern double    elemCubeValues[8];
extern double    elemCubePositions[8][3];

extern Triangle  Triangles[5];

#endif
/******************************************************************************/
/******************************************************************************/
