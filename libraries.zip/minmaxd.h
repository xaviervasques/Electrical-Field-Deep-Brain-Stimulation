/*  ../libmy/minmaxd.h                                                        */
/*   Mennessier Gerard             960315                                     */
/*   Last revised M.G.             990415                                     */

#ifndef  DEF_MINMAXD_H
#define  DEF_MINMAXD_H

#include  <stddef.h>

void      minmaxd(size_t nx,double *xp,double *xminp,double* xmaxp);

#endif
/******************************************************************************/
/******************************************************************************/
