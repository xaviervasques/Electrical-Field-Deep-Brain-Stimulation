/*  URMAE/numerical/linear4/constant.phys.URMAE.def.h                         */
/*  Mennessier Gerard                 20000414                                */
/*  Last Revised : G.M.               20020406                                */

#ifndef  DEF_CONSTANT_PHYS_URMAE_DEF_H
#define  DEF_CONSTANT_PHYS_URMAE_DEF_H

                                             /** Conductivity KAPPA_ (ohm * m)^-1 **/
#define   KAPPA_     0.1

#endif
/******************************************************************************/
/******************************************************************************/
