/*  URMAE/orientHaut/linear4.GL.V1/gm.linear4.initsolve.glob.h                */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20020410                                */

#ifndef  DEF_GM_LINEAR4_INITSOLVE_GLOB_H
#define  DEF_GM_LINEAR4_INITSOLVE_GLOB_H

#include  "gridZ.linear4.h"
#include  "gridR.linear4.h"
#include  "cylPot.linear4.h"
#include  "eltrdPot.linear4.h"
#include  "pot.linear4.h"

extern    gmGridZ        gridZi_mm;
extern    gmGridR        gridRi_mm;
extern    gmEltrdPot     eltrdPf;
extern    gmCylPot       cylPf;
extern    gmPot          Vf,  gradVf;

#endif
/******************************************************************************/
/******************************************************************************/
