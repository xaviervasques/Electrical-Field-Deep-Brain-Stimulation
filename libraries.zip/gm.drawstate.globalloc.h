/*  URMAE/orientHaut/linear4.GL.V1/gm.drawstate.globalloc.h                   */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20011220                                */

#ifndef  DEF_GM_DRAWSTATE_GLOBALLOC_H
#define  DEF_GM_DRAWSTATE_GLOBALLOC_H

#include  "utiVecChr.h"
#include  "utiCurve.level.h"
#include  "utiCurve.set.h"
                              /** PATIENT **/
chrVec    stateTitlePatientV = {0,0,NULL};

                              /** ELECTRICAL PARAMETERS **/
                                           /** current pin mode string, numerical **/
chrVec    stateTitlePinModV = {0,0,NULL};
int       statePinModp[4];
                                                            /** current neck mode **/
int       stateNeckMod;
                                            /** current voltage string, numerical **/
chrVec    stateTitleVoltageV = {0,0,NULL};
double    stateVoltage;
                                                     /** current impedance string **/
chrVec    stateTitleImpedanceV = {0,0,NULL};
double    stateImpedance;
double    statePredictedImpedance;

double    stateKappaEff;
                                          /** current function string code choice **/
char      stateVEIp[3] = {'V', 'E', 'I'};
int       stateVEI;
double  **stateFpp;                        /** pointer to choosen function values **/
lcZrange  stateLCrange;                  /** level origin, step, minimum, maximum **/

                              /** CURVES SETS **/
char     *stateTitlesp[6];

#endif
/******************************************************************************/
/******************************************************************************/
