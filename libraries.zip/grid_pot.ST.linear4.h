/*  URMAE/orientHaut/linear4.GL.V1/grid_pot.ST.linear4.h                      */
/*  Mennessier Gerard                 20011228                                */
/*  Last Revised : G.M.               20020410                                */

#ifndef  DEF_GRID_POT_ST_LINEAR4_H
#define  DEF_GRID_POT_ST_LINEAR4_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiAlloc.h"

typedef struct gmGridPotSTXYStruct
{ char     *unitnamep;        /** UNIT **/
  double   *alphap;                             /** director angle list in Radian **/
  size_t    alphaz;                                            /** allocated size **/
  size_t    alphax;                                                 /** used size **/
  double   *saxp;                                             /** small axis list **/
  size_t    saxz;
  size_t    saxx;
  double    zst;       /** z value in the ScannerTranslated frame. Needed for pot **/
  double   *potp;       /** potential values on this rectangular (alpha,rho) grid **/
  size_t    potz;
  size_t    potx;
  double  **potpp;              /** potential pointer (fixed rho, variable alpha) **/
  size_t    potpz;
  size_t    potpx;
} gmGridPotSTXY, *gmGridPotSTXYp;
  
gmGridPotSTXY *gmGridPotSTXYAlloc(size_t nz, char *progcallp);
void      gmGridPotSTXYPAlloc(size_t az, size_t rz, gmGridPotSTXY *p);
void      gmGridPotSTXYsetAlpha(gmGridPotSTXY *p);
void      gmGridPotSTXYsetSaxis(size_t rx, double *rhop, gmGridPotSTXY *p);
void      gmGridPotSTXYsetPot(double  **fpp, double zst, gmGridPotSTXY *p);
void      gmGridPotSTXYPrint(FILE *bufp, gmGridPotSTXY *p);
void      gmGridPotSTalphaSaxisZ2xy(double *xyp,
                                            double alphar, double saxis, double zst);
void      gmGridPotSTalphaSaxisZ2Exyz(double *xyzp,
                                            double alphar, double saxis, double zst);

#endif
/******************************************************************************/
/******************************************************************************/
