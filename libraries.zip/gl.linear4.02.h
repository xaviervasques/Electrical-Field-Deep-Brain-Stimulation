/*  bio_phys/URMAE/numerical/linearGL4/gl.linear4.02.h                        */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20011217                                */

#ifndef  DEF_GL_LINEAR4_02_H
#define  DEF_GL_LINEAR4_02_H

void      gmGl02InitWin(void);
void      gmGl02Display(void);
void      gmGl02Reshape(int w, int h);

void      gmGl020InitWin(void);
void      gmGl020Display(void);
void      gmGl020Reshape(int w, int h);
void      gmGl020MN(int menuindex);

void      gmGl021InitWin(void);
void      gmGl021Display(void);
void      gmGl021Reshape(int w, int h);
void      gmGl021KB(unsigned char key, int x, int y);
void      gmGl021MN(int menuindex);

void      gmGl022InitWin(void);
void      gmGl022Display(void);
void      gmGl022Reshape(int w, int h);
void      gmGl022KB(unsigned char key, int x, int y);
void      gmGl022MN(int menuindex);

void      gmGl023InitWin(void);
void      gmGl023Display(void);
void      gmGl023Reshape(int w, int h);
void      gmGl023KB(unsigned char key, int x, int y);
void      gmGl023MN(int menuindex);

#endif
/******************************************************************************/
/******************************************************************************/
