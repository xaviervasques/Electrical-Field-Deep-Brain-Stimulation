/*  URMAE/reconstruction.GM/V1/syslin.h                                       */
/*  Mennessier Gerard                 20060321                                */
/*  Last Revised : G.M.               20060325                                */
/*                                                                            */

#ifndef  DEF_SYSLIN_H
#define  DEF_SYSLIN_H

#include  <stddef.h>

void      syslin(size_t npts, double *centerxyzp, double *weightp);

#endif
/******************************************************************************/
/******************************************************************************/
