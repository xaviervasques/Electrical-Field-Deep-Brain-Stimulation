/*  URMAE/orientHaut/linear4.GL.V1/gm.drawstate.ST.statalloc.h                */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20020418                                */

#ifndef  DEF_GM_DRAWSTATE_ST_STATALLOC_H
#define  DEF_GM_DRAWSTATE_ST_STATALLOC_H

#include  "utiVecChr.h"
#include  "utiCurve.level.h"
#include  "utiCurve.set.h"
#include  "grid_pot.ST.linear4.h"

                              /** GEOMETRIC PARAMETERS **/
                              /** SCANNER (TRANSLATED) Frame **/
                                                                 /** psi rotation **/
static    chrVec    stateSTpsiRotV = {0,0,NULL};     /** (in degree): char string **/
static    double    stateSTpsiRotDeg,  stateSTpsiRotRad;  
                                                              /** section z value **/
static    chrVec    stateSTzhV = {0,0,NULL};                      /** char string **/
static    double    stateSTzh;
static    gmGridPotSTXY  stateSTGridPotalphsax;   /** alpha, small axis, zst, pot **/

                                       /** limits for effective drawing in window **/
static    double    stateSTLimRho[2] = {-8.1, +8.1},
                    stateSTLimZ[2] = {-8.1, +8.1},
                    stateSTLimX[2] = {-8.1, +8.1},
                    stateSTLimY[2] = {-8.1, +8.1};

                              /** CURVES SETS **/
                              /** SCANNER (TRANSLATED) Frame **/
static    char     *stateSTTitlesp[6];

static    cSetVec   STRZeltrdAxisCSetv = {0,0,NULL},
                    STRZtitleCSetv = {0,0,NULL},
                    STRZlevelCSetv = {0,0,NULL};
static    cSetVec   STRZallCSetv = {0,0,NULL};

static    cSetVec   STXYeltrdAxisCSetv = {0,0,NULL},
                    STXYtitleCSetv = {0,0,NULL},
                    STXYlevelCSetv = {0,0,NULL};
static    cSetVec   STXYallCSetv = {0,0,NULL};

#endif
/******************************************************************************/
/******************************************************************************/
