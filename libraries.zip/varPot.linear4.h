/*  bio_phys/URMAE/numerical/linear4/varPot.linear4.h                         */
/*  Mennessier Gerard                 20000414                                */
/*  Last Revised : G.M.               20020114                                */

#ifndef   DEF_VARPOT_LINEAR4_H
#define   DEF_VARPOT_LINEAR4_H

#include  "utistdIO.h"

#include  "eltrdPot.linear4.h"
#include  "cylPot.linear4.h"
#include  "varGrid.linear4.h"
#include  "pot.linear4.h"
#include  "pot_funcBasis.def.h"                                    /** for NCOEF_ **/

typedef struct gmVarPotStruct
{ gmVarGrid    *varGridp;
  double       *varp;
  size_t        ndz;                                           /** allocated size **/
  size_t        ndx;                  /** number of nodes with potential variable **/
  gmEltrdPot   *eltrdPotp;
  gmCylPot     *cylPotp;
} gmVarPot, *gmVarPotp;
    
void      gmVarPotPAllocZero(gmVarPot *p, gmVarGrid *varGridp,
                                                 gmEltrdPot *eltrdp, gmCylPot *cylp);
void      gmVarPotSetSCoef(gmVarPot *p, double **scoefpp, int *sorderp);
void      gmVarPotSetModes(gmVarPot *p, int neckMod, int *modp);
void      gmVarPotSetV(gmVarPot *p, double infiniv, double *vp);
void      gmVarPotPrint(FILE *bufOut, gmVarPot *p);
void      gmVarPotWrite(FILE *bufWritep, gmVarPot *p);
void      gmVarPotRead(FILE *bufReadp, gmVarPot *p);
void      gmVarPotCpy(gmVarPot *pf, gmVarPot *pi);
void      gmVarP2P(gmPot *Potp, gmVarPot *varPotp);
void      gmP2VarP(gmVarPot *varPotp, gmPot *Potp);

#endif
/******************************************************************************/
/******************************************************************************/
