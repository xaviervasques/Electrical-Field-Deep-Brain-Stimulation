/*  essai/C/utiCurve.ellipse.h                                                */
/*  Mennessier Gerard                   20010502                              */
/*  Last revised M.G.                   20030625                              */
/*                                                                            */

#ifndef  DEF_UTICURVE_ELLIPSE_H
#define  DEF_UTICURVE_ELLIPSE_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiAlloc.h"
#include  "utiMath.type.def.h"
#include  "utiCurve.GC.h"
#include  "utiCurve.Vec.h"

/******************************************************************************/
/*  cEllipse : arc of an ellipse                                              */
/*                                                                            */
/* orient : angle of first axis (usually large one) with Ox axis, in DEGREE   */
/* anglp[2] : first and last angles, measured from first axis, in DEGREES     */
/*            as measured on a drawing with equal scale in x and y directions */
/*            (true angles , not director circle angles)                      */
/*                                                                            */
/* anglDp[2]: first and last director angles, in DEGREES                      */
/*    i.e. Point Initial =                                                    */
/*    (axisp[0]*cos(anglDp[0]*deg2rad), axisp[1]*sin(anglDp[0]*deg2rad)       */
/*         Point Final   =                                                    */
/*    (axisp[0]*cos(anglDp[1]*deg2rad), axisp[1]*sin(anglDp[1]*deg2rad)       */
/*                                                                            */
/******************************************************************************/
typedef struct cEllipse                                           /** ellipse arc **/
{ double        xp[2];       /** x,y coord of center **/
  double        axisp[2];    /** axis lengths. ONLY fabs(axis) is used **/
  double        orient;      
  double        anglTp[2];   /**  initial and final "true" angles **/
  double        anglDp[2];   /**  initial and final director angles **/
  curveGC      *gcp;         /** pointer to associated GC **/
  myBOOL        closed;      /** if TRUE, close the circle **/
} cEllipse, *cEllipsep;

cEllipse  *cEllipseAlloc(size_t  nz,char *progcallp);
cEllipse  *cEllipseChkRealloc(cEllipse *p,size_t *nzp,size_t neednz,size_t incrnz,
                                                                    char *progcallp);
void      cEllipsePrint(FILE *bufp, cEllipse *p);
void      cEllipseZero(cEllipse *p);
void      cEllipseSetCAO(cEllipse *p, double *xp, double *axisp, double orient);
void      cEllipseSetTru(cEllipse *p, double *anglTrup);
void      cEllipseSetDir(cEllipse *p, double *anglDirp);
void      cEllipseSetCAOTru(cEllipse *p, double *xp, double *axisp,
                                                    double orient, double *anglTrup);
void      cEllipseSetCAODir(cEllipse *p, double *xp, double *axisp,
                                                    double orient, double *anglDirp);
void      cEllipseCopypp(cEllipse *pf, cEllipse *pi);
void      cEllipseCopyp(cEllipse *pf, cEllipse cc);
double    cEllipseAnglDir2Tru(double *axisp, double anglDir);
double    cEllipseAnglTru2Dir(double *axisp, double anglTru);
int       cEllipseAngleDetermination360(double alphaDeg);
int       cEllipseAngleIsClosed(double *alphaDegp);

/******************************************************************************/
/*  cEllipse : arc of an ellipse                                              */
/******************************************************************************/
typedef struct cEllipseVec
{ size_t        z;
  size_t        x;
  cEllipse      *p;
  curveGC      *gcp;         /** pointer to associated GC **/
} cEllipseVec, *cEllipseVecp;

#define   cEllipseVecAlloc(nz,prognamp) (cEllipseVec *)myCurveVecAlloc((nz),prognamp)
#define   cEllipseVecChkRealloc(p,nzp,needz,inz,pronamp)              \
                         (cEllipseVec *)myCurveVecChkRealloc(p,nzp,needz,inz,pronamp)
void      cEllipsePVecAlloc(cEllipseVec *vecp,size_t  nz);
void      cEllipsePVecRealloc(cEllipseVec *vecp,size_t neednz,size_t incrnz);
void      cEllipsePVecFree(cEllipseVec *vecp);
void      cEllipseVecFree(cEllipseVec *vecp);
void      cEllipseVecPrint(FILE *bufp, cEllipseVec *vecp);
void      cEllipseVecInc1(cEllipseVec *vecp, cEllipse cc);
void      cEllipseVecInc1p(cEllipseVec *vecp, cEllipse *ccp);
void      cEllipseVecInc1DataTru(cEllipseVec *vecp, double *xp, double *axisp,
                                                    double orient, double *anglTrup);
void      cEllipseVecInc1DataDir(cEllipseVec *vecp, double *xp, double *axisp,
                                                    double orient, double *anglDirp);

#endif
/******************************************************************************/
/******************************************************************************/
