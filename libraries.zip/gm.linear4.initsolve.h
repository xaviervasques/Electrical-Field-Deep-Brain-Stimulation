/*  URMAE/orientHaut/linear4.GL.V1/gm.linear4.initsolve.h                     */
/*  Mennessier Gerard                 20000414                                */
/*  Last Revised : G.M.               20020410                                */

#ifndef  DEF_GM_LINEAR4_INITSOLVE_H
#define  DEF_GM_LINEAR4_INITSOLVE_H

#include  "utistdIO.h"
#include  "cylPot.linear4.h"
#include  "eltrdPot.linear4.h"

char    **gmGetFilenamepp();
FILE    **gmGetStreambufpp();
gmCylPot      *gmGetCylPfp();
gmEltrdPot    *gmGetEltrdPfp();
void      gmInitBase(int argx, char *argvpp[]);
void      gmSolveFromBasis(char *voltstrp, char *pinmodstrp);
double    gmGetImpedance();

#endif
/******************************************************************************/
/******************************************************************************/
