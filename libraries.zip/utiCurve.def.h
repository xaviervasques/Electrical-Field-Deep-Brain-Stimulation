/*  ../libmy/utiCurve.def.h                                                   */
/*  Mennessier Gerard                   20010628                              */
/*       revised M.G.                   20020902                              */
/*  Last revised M.G.                   20050207                              */
/*                                                                            */

#ifndef  DEF_UTICURVE_DEF_H
#define  DEF_UTICURVE_DEF_H

#define   MY_CPOLY       1
#define   MY_CPOLYV      2
#define   MY_CSEGV      11
#define   MY_LCSEGV     21
#define   MY_CSTRING    31
#define   MY_CCIRCLE    41
#define   MY_CCIRCLEV   42
#define   MY_CELLIPSE   45
#define   MY_CELLIPSEV  46
#define   MY_CPOINTS    51

#endif
/******************************************************************************/
/******************************************************************************/
