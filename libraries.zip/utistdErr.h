/*   ../libmy/utistdErr.h                                                     */
/*   Mennessier Gerard                  19940822                              */
/*   Last revised M.G.                  20040504                              */

#ifndef  DEF_UTISTDERR_H
#define  DEF_UTISTDERR_H

#include  <stdio.h>

#define   myOK                0
#define   myALLOC_ERR         1
#define   myFILE_OPEN_ERR     2
#define   myFILE_READ_ERR     3
#define   myFILE_WRITE_ERR    4
#define   myARG_MISSING_ERR   5
#define   myILLEGAL_CASE      6

void      myErr0(int exitcod, FILE *stream, char *formatp, ...);
void      myErr1(int exitcod, FILE *stream, char *prognamp, char *formatp, ...);
void      myErr2(int exitcod, FILE *stream, char *srcfilenamp, char *prognamp,
                                                                 char *formatp, ...);

#endif
/******************************************************************************/
/******************************************************************************/
