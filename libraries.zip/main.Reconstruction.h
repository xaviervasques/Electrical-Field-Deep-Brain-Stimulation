/* X.V. : 03/06/2006*/

#ifndef DEF_MAIN_RECONSTRUCTION_H
#define DEF_MAIN_RECONSTRUCTION_H

void choiceGridParameters();
int  mainparameters(int argxi, char *argvpp[]);

/* Dimension de la grille th�orique */
static int grilleSize = 50;

#endif
