/*  URMAE/orientHaut/linear4.GL.V1/gl.linear4.1.h                             */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20020410                                */

#ifndef  DEF_GL_LINEAR4_1_H
#define  DEF_GL_LINEAR4_1_H

void      gmGl1InitWin(void);
void      gmGl1Display(void);
void      gmGl1Reshape(int w, int h);
void      gmGl1KB(unsigned char key, int x, int y);

#endif
/******************************************************************************/
/******************************************************************************/
