/*  .../orientHaut/linear4.Common.V1/eltrd.def.h                              */
/*  Mennessier Gerard                 20000414                                */
/*  Last Revised : G.M.               20020109                                */

#ifndef  DEF_ELTRD_DEF_H
#define  DEF_ELTRD_DEF_H

#define   ELTRD_R_mm     0.635
#define   ELTRD_R_m      (ELTRD_R_mm * 0.001)
#define   NPX_           4         /* number of pins */
#define   NPEX_          2*NPX_    /* number of pinExtremities */
#define   ELTRD_I_mm     0.5       /* size of insulator between pins */
#define   ELTRD_C_mm     1.5       /* size of conductor pins */
#define   ELTRD_IX1_mm   0.5       /* size of cylindrical insulator near extremity */
#define   ELTRD_IX0_mm   1.0       /* size of ellipsoidal insulator at extremity */

#endif
/******************************************************************************/
/******************************************************************************/
