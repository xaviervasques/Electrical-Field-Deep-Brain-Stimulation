#ifndef  DEF_MARCHCUBE_H
#define  DEF_MARCHCUBE_H

typedef struct Triangle
{ double   *Vertpp[3];               /* les trois vertex qui composent un triangle */
  int       Nump[3];       /* num�ros des c�t�s aux quels appartient chaque vertex */
} Triangle;

int       marchCubePolygon(double isolevel);
int       Interpolate(double vect1[3], double vect2[3], double val1, double val2,
                                                    double isolevel, double vect[3]);

#endif
/******************************************************************************/
/******************************************************************************/
