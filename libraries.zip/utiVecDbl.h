/*  ../libmy/utiVecDbl.h                                                      */
/*  Mennessier Gerard                   940822                                */
/*  Last revised              M.G.      970505                                */

#ifndef  DEF_UTIVECDBL_H
#define  DEF_UTIVECDBL_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiAlloc.h"

typedef struct dblVec
{ size_t        z;
  size_t        x;
  double       *p;
} dblVec, *dblVecp;

#define  dblVecAlloc(nz,prognamp)            (dblVec *)myVecAlloc((nz),prognamp)
#define  dblVecChkRealloc(p,nzp,needz,inz,pronamp)              \
                              (dblVec *)myVecChkRealloc(p,nzp,needz,inz,pronamp)
/* extern    dblVec   *dblVecAlloc   (size_t nz, char *prognamp); */
extern    void      dblPVecAlloc  (dblVec *vecp,size_t  nz);
extern    void      dblPVecRealloc(dblVec *vecp,size_t neednz,size_t incrnz);
extern    void      dblPVecFree   (dblVec *vecp);
extern    void      dblVecFree    (dblVec *vecp);
extern    void      dblVecPrint   (FILE  *bufp,dblVec *vecp);
extern    void      dblVecInc1    (dblVec *vecp,double y);
extern    void      dblVecIncN    (dblVec *vecp,double *yp,size_t n);

#endif
/******************************************************************************/
/******************************************************************************/
