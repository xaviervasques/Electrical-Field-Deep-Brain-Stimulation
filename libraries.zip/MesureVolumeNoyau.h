 Le volume de la structure est de  : 431.006042 mm3

 Le volume de la moiti� posterieur de la structure est de : 213.847534 mm3

 Le volume de la moiti� ant�rieur de la structure est de : 217.156616 mm3

 La surface de la structure est de : 386.381226 mm2

 La surface de la moiti� post�rieur est de : 208.734726 mm2

 La surface de la moiti� ant�rieur est de : 177.646591 mm2

