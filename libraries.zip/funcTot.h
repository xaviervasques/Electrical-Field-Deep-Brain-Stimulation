#ifndef  DEF_FUNCTOT_H
#define  DEF_FUNCTOT_H

double    ftot(double *currentxyzp);
void      ftotGrad(double *fgradp, double *currentxyzp);
double    ftotValGrad(double *fgradp, double *currentxyzp);

#endif
/******************************************************************************/
/******************************************************************************/
