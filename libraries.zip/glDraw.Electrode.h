#ifndef  DEF_GLDRAW_ELECTRDDE_H
#define  DEF_GLDRAW_ELECTRODE_H

void      glDrawElectrode1(double theta, double phi);
void      glDrawElectrode2(double theta, double phi);
#endif
/******************************************************************************/
/******************************************************************************/
