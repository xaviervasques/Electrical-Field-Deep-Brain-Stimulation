/*  ../libmy/utiByteOrderENDIAN.h                                             */
/*  Mennessier Gerard                   20020528                              */
/*  Last Revised : G.M.                 20041011                              */

#ifndef  DEF_UTIBYTEORDERENDIAN_H
#define  DEF_UTIBYTEORDERENDIAN_H

typedef union unionByte4
{ unsigned char  uch[4];
  unsigned short ush[2];
  unsigned int   ui;
} unionByte4, *unionByte4p;

short    *utiByteOrderGet();
void      utiSwapB2(unsigned char *ucp, size_t ix);
void      utiCpySwapB2(unsigned char *ucfp, unsigned char *ucip, size_t ix);
void      utiSwapB4(unsigned char *ucp, size_t ix);
void      utiCpySwapB4(unsigned char *ucfp, unsigned char *ucip, size_t ix);

unsigned short utiSwapB2ushort(unsigned char *ucp);
unsigned int   utiSwapB4uint(unsigned char *ucp);

#endif
/******************************************************************************/
/******************************************************************************/
