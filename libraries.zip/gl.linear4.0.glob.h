/*  URMAE/orientHaut/linear4.GL.V1/gl.linear4.0.glob.h                        */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20020410                                */

#ifndef  DEF_GL_LINEAR4_0_GLOB_H
#define  DEF_GL_LINEAR4_0_GLOB_H

#include  <GL/glut.h>

extern    GLfloat   win0ew, win0eh;

#endif
/******************************************************************************/
/******************************************************************************/
