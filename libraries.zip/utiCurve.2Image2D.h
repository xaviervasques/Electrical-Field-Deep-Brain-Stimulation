/*  ../utiCurve.2Image2D.h                                                    */
/*  Mennessier Gerard                   20030612                              */
/*       revised M.G.                   20040428                              */
/*  Last revised M.G.                   20050208                              */
/*                                                                            */

#ifndef  DEF_UTICURVE_2Image2D_H
#define  DEF_UTICURVE_2Image2D_H

#include  <stddef.h>

#include  "utistdIO.h"
#include  "utiImage2D.h"
#include  "utiImage2D.Phys.h"

#include  "utiCurve.circle.h"
#include  "utiCurve.ellipse.h"
#include  "utiCurve.level.h"
#include  "utiCurve.poly.h"
#include  "utiCurve.seg.h"
#include  "utiCurve.string.h"
#include  "utiCurve.points.h"
#include  "utiCurve.set.h"

/******************************************************************************/
/**
                             physical boundaries, with OpenGL definition (p.292)

  if n pixels,
     dx = (xnxp[1] - xnxp[0])/n,             dy = (ynxp[1] - ynxp[0])/n
     scalex = 1/dx = n/(xnxp[1] - xnxp[0]),  ...

  pixel(0,0)   covers
     [xnxp[0], xnxp[0]+dx[  *  [ynxp[0], ynxp[0]+dy[

  pixel(ix,iy) covers
     [xnxp[0] + ix*dx, xnxp[0] + (ix+1)*dx[ * [ynxp[0] + iy*dy, ynxp[0] + (iy+1)*dy[
               and its center is
      xnxp[0] + (ix + 0.5)*dx,  ynxp[0] + (iy + 0.5)*dy
**/
/******************************************************************************/


/******************************************************************************/
void      c2Image2DgraphSetInk(unsigned char *inkp);

void      c2Image2DgraphSet(utiImage2D *ep, unsigned char *inkp, 
                                            utiImage2DPhys *physp, cSetVec *setvecp);
void      c2Image2DgraphSeg(utiImage2D *ep, unsigned char *inkip,
                                                  utiImage2DPhys *physp, cSeg *segp);
void      c2Image2DgraphSegV(utiImage2D *ep, unsigned char *inkip,
                                            utiImage2DPhys *physp, cSegVec *segvecp);
void      c2Image2DgraphPoly(utiImage2D *ep, unsigned char *inkip,
                                                    utiImage2DPhys *physp, cPoly *p);
void      c2Image2DgraphCircle(utiImage2D *ep, unsigned char *inkip, 
                                                utiImage2DPhys *physp, cCircle *ccp);
void      c2Image2DgraphEllipse(utiImage2D *ep, unsigned char *inkip, 
                                                 utiImage2DPhys *physp, cEllipse *p);

void      c2Image2DgraphLcSeg(utiImage2D *ep, unsigned char *inkip,
                                             utiImage2DPhys *physp, lcSegVec *lcsvp);
void      c2Image2DgraphPolyV(utiImage2D *ep, unsigned char *inkip,
                                              utiImage2DPhys *physp, cPolyVec *vecp);
void      c2Image2DgraphCircleV(utiImage2D *ep, unsigned char *inkip,
                                            utiImage2DPhys *physp, cCircleVec *vecp);
void      c2Image2DgraphEllipseV(utiImage2D *ep, unsigned char *inkip,
                                           utiImage2DPhys *physp, cEllipseVec *vecp);
void      c2Image2DgraphPoints(utiImage2D *ep, unsigned char *inkip, 
                                                  utiImage2DPhys *physp, cPoints *p);

#endif
/******************************************************************************/
/******************************************************************************/
