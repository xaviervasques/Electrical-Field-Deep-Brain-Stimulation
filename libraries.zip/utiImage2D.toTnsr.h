/*  ../libmy/utiImage2D.toTnsr.h                                              */
/*  Mennessier Gerard                   20041011                              */
/*  Last revised M.G.                   20041011                              */
 
#ifndef  DEF_UTIIMAGE2D_TOTNSR_H
#define  DEF_UTIIMAGE2D_TOTNSR_H
 
#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiImage2D.h"
#include  "utiTnsr.h"

void    utiImage2DtoTnsrInt(tnsr2int *tp, utiImage2D *ep);
void    utiImage2DtoTnsrDbl(tnsr2dbl *tp, utiImage2D *ep);
 
#endif
/******************************************************************************/
/******************************************************************************/
