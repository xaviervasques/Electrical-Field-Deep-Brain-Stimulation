/*   ..libmy/utistdMem.h                                                     */
/*   Mennessier Gerard             940822                                     */
/*   Last revised M.G.             950824                                     */

#ifndef  DEF_UTISTDMEM_H
#define  DEF_UTISTDMEM_H

#include  <stddef.h>

#define  DEF_MAPMEM
/* #undef  DEF_MAPMEM */

#ifdef  SPARCM
extern void   *memchr(const void *, int, size_t);
extern int     memcmp(const void *, const void *, size_t);
extern void   *memcpy(void *, const void *, size_t);
extern void   *memset(void *, int, size_t);
                  /*****  extern void *memmove(void *, const void *, size_t);  *****/
 
#else
#include  <string.h>
#endif                                                          /** ifdef  SPARCM **/

#ifdef   DEF_MAPMEM
#define   memChr    memchr
#define   memCmp    memcmp
#define   memCpy    memcpy
#define   memSet    memset

#ifdef   SPARCM
extern    void     *memMove(void *,const void *,size_t);
#else
#define   memMove   memmove
#endif                                                          /** ifdef  SPARCM **/

#else
extern    void     *memChr (const void *,int,size_t);
extern    int       memCmp (const void *,const void *,size_t);
extern    void     *memCpy (void *,const void *,size_t);
extern    void     *memMove(void *,const void *,size_t);
extern    void     *memSet (void *,int,size_t);
#endif                                                      /** ifdef  DEF_MAPMEM **/

#endif                                                  /** ifndef  DEF_UTISTDMEM **/
/******************************************************************************/
/******************************************************************************/
