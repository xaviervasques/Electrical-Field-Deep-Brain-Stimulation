/*  ../libmy/utiVecMyVec.h                                                    */
/*  Mennessier Gerard                   970513                                */
/*  Last revised              M.G.      970513                                */

#ifndef  DEF_UTIVECMYVEC_H
#define  DEF_UTIVECMYVEC_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiAlloc.h"

void      myVecPrint(FILE *bufp,myVec *p);
void      myVecArrayPrint(FILE *bufp,myVec *p,size_t n);
void      myVecZero(myVec *p);
void      myVecCpy1F(myVec *xfp,void *p,size_t z,size_t x);
void      myVecCpy1(myVec *xfp,myVec xi);
void      myVecCpy1p(myVec *xfp,myVec *xip);
void      myVecPVecAlloc(myVec *vecp,size_t  nz);
void      myVecPVecRealloc(myVec *vecp,size_t neednz,size_t incrnz);
void      myVecPVecFree(myVec *vecp);
void      myVecVecInc1(myVec *vecp,myVec y);
void      myVecVecIncN(myVec *vecp,myVec *yp,size_t n);

#endif
/******************************************************************************/
/******************************************************************************/
