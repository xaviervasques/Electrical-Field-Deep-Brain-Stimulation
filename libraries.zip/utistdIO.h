/*   ../libmy/utistdIO.h                                                      */
/*   Mennessier Gerard             940822                                     */
/*   Last revised M.G.             961108                                     */
 
/******************************************************************************/
/*  sprintf: SUN   return value char *   (initial memory address always)      */
/*           ANSI               int      (number of transmitted char)         */
/***** -->  better to use sPrintF                                  *****/
/*                                                                            */
/*  fputc  : SUN   has first arg of type  char                                */
/*           ANSI                         int                                 */
/***** -->  better to use  fPutC                                          *****/
/*                                                                            */
/*  fileno : SUN   return value char                                          */
/*           POSIX              int                                           */
/***** -->  better to use  fileNo                                         *****/
/******************************************************************************/

#ifndef  DEF_UTISTDIO_H
#define  DEF_UTISTDIO_H
                
#ifndef  _POSIX_SOURCE
#define   POSIXwasnotdef
#define  _POSIX_SOURCE                                       /** for POSIX fileno **/
#endif

#define  DEF_MAPIO
/*  #undef   DEF_MAPIO  */  

#include  <stdio.h>                                 /** define FILE in particular **/

#ifdef  SPARCM
#include  <sys/stdtypes.h>
extern int      fclose(FILE *);
extern int      fflush(FILE *);
extern void     setbuf(FILE *, char *);
extern int      setvbuf(FILE *, char *, int, size_t);
extern int      fprintf(FILE *, const char *,...);
extern int      printf(const char *, ...);
extern char    *sprintf(char *, const char *, ...);
extern int      fscanf(FILE *, const char *, ...);
extern int      scanf(const char *, ...);
extern int      sscanf(const char *, const char *, ...);
extern int      fgetc(FILE *);
extern char    *fgets(char *,int,FILE *);
extern int      fputc(char, FILE *);                  /* (int,FILE*)  in ANSI */
extern int      fputs(const char *, FILE *);
extern int      puts(const char *);
extern size_t   fread(void * , size_t , size_t , FILE *);
extern size_t   fwrite(const void *, size_t, size_t, FILE *);
extern int      fseek(FILE *, long int, int);
#define   SEEK_SET   0
#define   SEEK_CUR   1
#define   SEEK_END   2
#endif

extern int      fileNo(FILE *);

/* if following block active (not commented) should need utiIo.c only for SUN */
/* if following block commented (not active) need utiIo.c                     */
/*                    and activated block with extern...fPrintF,...,fPutC     */

#ifdef   DEF_MAPIO
#define   fPrintF   fprintf
#ifdef  SPARCM
/*     #define         fPutC(i,f)   fputc( (char)(i) , f) */
extern    int       sPrintF(char *membufp, const char *formatp, ...);
extern    int       fPutC(int, FILE *);
#else
#define   fPutC     fputc
#define   sPrintF   sprintf
#endif                                                             /* ifdef SPARCM */

#else
extern    int       fPrintF(FILE *stream,  const char *formatp, ...);
extern    int       sPrintF(char *membufp, const char *formatp, ...);
extern    int       fPutC(int, FILE *);
#endif                                                          /* ifdef DEF_MAPIO */

#ifdef   POSIXwasnotdef
#undef   POSIXwasnotdef
#undef  _POSIX_SOURCE
#endif

#endif                                                    /* ifndef DEF_UTISTDIO_H */
/******************************************************************************/
/******************************************************************************/
