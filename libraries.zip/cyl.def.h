/*  .../orientHaut/linear4.Common.V1/cyl.def.h                                */
/*  Mennessier Gerard                 20020325                                */
/*  Last Revised : G.M.               20020326                                */

#ifndef  DEF_CYL_DEF_H
#define  DEF_CYL_DEF_H

#define   CYL_R_mm     40.0
#define   CYL_Zmin_mm -40.0
#define   CYL_Zmax_mm  40.0
#define   NECK_R_mm    20.0

#endif
/******************************************************************************/
/******************************************************************************/
