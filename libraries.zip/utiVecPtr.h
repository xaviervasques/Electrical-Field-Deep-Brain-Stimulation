/*  ../libmy/utiVecPtr.h                                                      */
/*  Mennessier Gerard                   940822                                */
/*  Last revised              M.G.      970505                                */

#ifndef  DEF_UTIVECPTR_H
#define  DEF_UTIVECPTR_H

#include  <stddef.h>
#include  "utistdIO.h"

typedef struct ptrVec
{ size_t        z;
  size_t        x;
  void        **p;
} ptrVec, *ptrVecp;

#define  ptrVecAlloc(nz,prognamp)            (ptrVec *)myVecAlloc((nz),prognamp)
#define  ptrVecChkRealloc(p,nzp,needz,inz,pronamp)              \
                              (ptrVec *)myVecChkRealloc(p,nzp,needz,inz,pronamp)
/* extern    ptrVec   *ptrVecAlloc   (size_t nz, char *prognamp); */
/* extern    ptrVec   *ptrVecChkRealloc(void *p,size_t *nzp,size_t neednz,
                                                   size_t incrnz, char *prognamp); */
extern    void      ptrPVecAlloc  (ptrVec *vecp,size_t  nz);
extern    void      ptrPVecRealloc(ptrVec *vecp,size_t neednz,size_t incrnz);
extern    void      ptrPVecFree   (ptrVec *vecp);
extern    void      ptrVecFree    (ptrVec *vecp);
extern    void      ptrVecPrint   (FILE  *bufp,ptrVec *vecp);
extern    void      ptrVecStrPrint(FILE  *bufp, ptrVec *vecp);
extern    void      ptrVecInc1    (ptrVec *vecp,void *yp);
extern    void      ptrVecIncN    (ptrVec *vecp,void **ypp,size_t n);

#endif
/******************************************************************************/
/******************************************************************************/
