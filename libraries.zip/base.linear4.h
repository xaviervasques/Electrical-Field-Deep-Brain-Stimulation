/*  URMAE/orientHaut/linear4.Common.V1/base.linear4.h                         */
/*  Mennessier Gerard                 20000414                                */
/*  Last Revised : G.M.               20020410                                */

#ifndef  DEF_BASE_LINEAR4_H
#define  DEF_BASE_LINEAR4_H

#include  "utistdIO.h"
#include  "utiTnsr.h"
#include  "gridZ.linear4.h"
#include  "gridR.linear4.h"
#include  "varGrid.linear4.h"
#include  "cylPot.linear4.h"
#include  "eltrdPot.linear4.h"
#include  "pot.linear4.h"
#include  "varPot.linear4.h"

int       basisGet(gmVarPot *varVbsp, gmPot *Vbsp, 
                   gmEltrdPot *eltrdPbsp, gmCylPot *cylPbsp,
                   gmVarGrid *varGridip, gmGridR *gridRip, gmGridZ *gridZip,
                   gmGridR *gridRi_mmp, gmGridZ *gridZi_mmp,
                                                       FILE *bufOutp, FILE *bufpp[]);
void      basisGetGA4(gmVarPot *varVbp, tnsr2dbl *gAtnsrp);
void      basisGetSA4fromPINS(FILE *bufp, double **gapp, double **sapp, double *sbp,
                                              int bi, char *pinmodstrp, double veff);
void      basisSolve4(FILE *bufp, tnsr2dbl *satp, tnsr2dbl *sbtp, int *newpinmodsip, 
                           gmCylPot *cylPfp,   gmEltrdPot *eltrdPfp,   gmPot *Vfp,
                           gmCylPot *cylPbsp, gmEltrdPot *eltrdPbsp, gmPot *Vbsp);

#endif
/******************************************************************************/
/******************************************************************************/
