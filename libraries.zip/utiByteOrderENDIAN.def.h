/*  ../libmy/utiByteOrderENDIAN.def.h                                         */
/*  Mennessier Gerard                   20020528                              */
/*  Last Revised : G.M.                 20040503                              */

#ifndef  DEF_UTIBYTEORDERENDIAN_DEF_H
#define  DEF_UTIBYTEORDERENDIAN_DEF_H

/** definition of possible values of byte order, equivalent to that of X.h   **/
#ifndef   myLSBFirst
#define   myLSBFirst  0
#endif
#ifndef   myMSBFirst
#define   myMSBFirst  1
#endif

#ifndef   my2UBYTEStoUSHORT
#define   my2UBYTEStoUSHORT(BYTEORDER, UCP, USH)                               \
          if(BYTEORDER)                                                        \
          { USH = ((unsigned char)*(UCP   ) << 8) | (unsigned char)*(UCP +1);  \
          }                                                                    \
          else                                                                 \
          { USH = ((unsigned char)*(UCP +1) << 8) | (unsigned char)*(UCP   );  \
          }                                                        
#endif

#endif
/******************************************************************************/
/******************************************************************************/
/* 
 INTEL is LSBFirst (pcMenesG, kaki, scanner)
 SUN   is MSBFirst (mira)
 SGI   is MSBFirst (sirius)
*/
