/*  ../libmy/utiImage2D.Phys.h                                                */
/*  Mennessier Gerard                   20030618                              */
/*  Last Revised : G.M.                 20040428                              */
  
#ifndef  DEF_UTIIMAGE2D_PHYS_H
#define  DEF_UTIIMAGE2D_PHYS_H

                     /** information to relate "physical units" to "pixel units"  **/
                            /** xnxp : physical x min and max; deltax = max - min **/
         /** pixdx = deltax /(pixel width),  convert (pixel number) into physical **/
        /** scalex = (pixel width)/ deltax,  convert physical into (pixel number) **/

typedef struct utiImage2DPhys
{ double    xnxp[2];
  double    ynxp[2];
  double    deltax;
  double    deltay;
  double    pixdx;
  double    pixdy;
  double    scalex;
  double    scaley;
} utiImage2DPhys, *utiImage2DPhysp;


void      utiImage2DPhysSetBoundary(utiImage2DPhys *physWinp,
                                                       double xnx[2], double ynx[2]);
void      utiImage2DPhysSetWH(utiImage2DPhys *physWinp, int w, int h);

#endif
/******************************************************************************/
/******************************************************************************/
