/*  libc/recipe2double/recipe.linmin.statalloc.h                              */
/** VECTOR and MATRIX INDICES FROM 0 to DIM-1                                **/
/** VECTOR and MATRIX : DOUBLE version                                       **/

#ifndef  DEF_LINMIN_STATALLOC_H
#define  DEF_LINMIN_STATALLOC_H

static    int       ncom;
static    double   *pcom, *xicom, *xtcom;
static    double    (*nrfunc)(double []);

#endif
/******************************************************************************/
/******************************************************************************/
