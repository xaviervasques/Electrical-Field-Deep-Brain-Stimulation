/*  URMAE/orientHaut/linear4.GL.V1/gm.drawstate.glob.h                       */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20020410                                */

#ifndef  DEF_GM_DRAWSTATE_GLOB_H
#define  DEF_GM_DRAWSTATE_GLOB_H

#include  "utiVecChr.h"
#include  "utiCurve.level.h"
#include  "utiCurve.set.h"
                              /** PATIENT **/
extern    chrVec    stateTitlePatientV;

                              /** ELECTRICAL PARAMETERS **/
                                           /** current pin mode string, numerical **/
extern    chrVec    stateTitlePinModV;
extern    int       statePinModp[4];
                                                            /** current neck mode **/
extern    int       stateNeckMod;
                                            /** current voltage string, numerical **/
extern    chrVec    stateTitleVoltageV;
extern    double    stateVoltage;
                                                     /** current impedance string **/
extern    chrVec    stateTitleImpedanceV;
extern    double    stateImpedance;
extern    double    statePredictedImpedance;

extern    double    stateKappaEff;
                                          /** current function string code choice **/
extern    char      stateVEIp[3];
extern    int       stateVEI;
extern    double  **stateFpp;              /** pointer to choosen function values **/
extern    lcZrange  stateLCrange;        /** level origin, step, minimum, maximum **/

                              /** CURVES SETS **/
extern    char     *stateTitlesp[6];

#endif
/******************************************************************************/
/******************************************************************************/
