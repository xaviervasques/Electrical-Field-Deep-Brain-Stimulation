/*  ../libmy/utiClassRangeLng.h                                               */
/*  Mennessier Gerard                   940810                                */
/*  Last Revised              M.G.      970421                                */

#ifndef   UTICLASSRANGELNG_H
#define   UTICLASSRANGELNG_H

#include  <stddef.h>

void      ranindLng(long *xp,int *indp,size_t nz);
int       classLng(int *indexp,long x,long *xp,size_t nx);

#endif
/******************************************************************************/
