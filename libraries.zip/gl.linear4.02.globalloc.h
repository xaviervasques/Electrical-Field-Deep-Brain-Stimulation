/*  bio_phys/URMAE/numerical/linearGL4/gl.linear4.02.globalloc.h              */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20030509                                */

#ifndef  DEF_GL_LINEAR4_02_GLOBALLOC_H
#define  DEF_GL_LINEAR4_02_GLOBALLOC_H

#include  <GL/glut.h>
#include  "utiVecChr.h"

GLfloat   win02ew, win02eh,
          win020ew, win020eh, win021ew, win021eh, win022ew, win022eh, 
                                                                  win023ew, win023eh;

                  /** width and height of w02. subsubwindows inside subwindow w02 **/
GLfloat   rs02w  = 1.0, rs02h  = 0.20;
GLfloat   rs020w = 0.20, rs021w = 0.34, rs022w = 0.23, rs023w = 0.23;
GLfloat   rs020h = 0.7, rs021h = 0.7, rs022h = 0.7, rs023h = 0.7;
                          /** position of w02. subsubwindows inside subwindow w02 **/
                        /** p021w = p020w + rs020w; p022w = p021w + rs021w;  ...  **/
GLfloat   p02w = 0.0,   p02h = 0.4;
GLfloat   p020w = 0.0,  p021w = 0.2,  p022w = 0.54,  p023w = 0.77;
GLfloat   p020h = 0.3,  p021h = 0.3,  p022h = 0.3,  p023h = 0.3;

char     *veiStrpp[3] = {"Potentiel", "Field", "Current"};
char      veiChrp[3] = {'V', 'E', 'I'};
int       VEI;

chrVec    psiEltrdRotV = {0,0,NULL};
double    psiEltrdRot;

chrVec    zhEltrdV = {0,0,NULL};
double    zhEltrd;

chrVec    rhozScaleRatioV = {0,0,NULL};
double    rhozScaleRatio;

#endif
/******************************************************************************/
/******************************************************************************/
