/*  ../libmy/echel.h                                                          */
/*   Mennessier Gerard             990415                                     */
/*   Last revised M.G.             990415                                     */

#ifndef  DEF_ECHEL_H
#define  DEF_ECHEL_H

#include  <stddef.h>

double    echel(double x);

#endif
/******************************************************************************/
/******************************************************************************/
