/*  ../libmy/utiImage3D.h                                                     */
/*  Mennessier Gerard                   20031010                              */
/*  Last revised M.G.                   20040503                              */

#ifndef  DEF_UTIIMAGE3D_H
#define  DEF_UTIIMAGE3D_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiVecChr.h"
#include  "utiVecUInt.h"
#include  "utiImage0D.h"
#include  "utiImage2D.h"

/******************************************************************************/
typedef struct  utiImage3D
{ utiImage0D   im0D;
  chrVec       dataV;
                          /** allocated BYTE size per row ( >= wpx*bytesPerPixel) **/
  size_t  wbz;
  size_t  wpx;                                    /** width, PIXEL number per row **/
  size_t  hpx;                                         /** height, number of rows **/

             /** allocated BYTE size per 2D rectangle ( >= hpx*wpx*bytesPerPixel) **/
  size_t  recbz;
  size_t  recpx;                  /** PIXEL number per 2D rectangle ==  hpx * wpx **/
  size_t  zpx;           /** 2D rectangle number = space or time ... slice number **/
  uintVec       graymin2DV;                /* uiVec of the zpx min for each slice **/
  uintVec       graymax2DV;                /* uiVec of the zpx max for each slice **/
  unsigned int  graymin3D;                                 /** minimum gray value **/
  unsigned int  graymax3D;                                 /** maximum gray value **/
} utiImage3D, *utiImage3Dp;

/******************************************************************************/

void      utiImage3DdataPVecAlloc(utiImage3D *ep, size_t dataz, size_t zz);
void      utiImage3DdataPVecRealloc(utiImage3D *ep,
                  size_t needataz, size_t dataincrnz, size_t needzz, size_t incrnzz);
void      utiImage3DdataPVecFree(utiImage3D *ep);
void      utiImage3DZero(utiImage3D *ep);

void      utiImage3DdataBytesPrint(FILE *streamp, utiImage3D *ep);
void      utiImage3DPrint(FILE *streamp, utiImage3D *ep);

void      utiImage3DGet2D(utiImage3D *e3p, utiImage2D *e2p, int iz);
short     utiImage3DAdd2D(utiImage3D *e3p, utiImage2D *e2p);

              /** Relevant ONLY when pixels are ushort GRAY LEVELS (or luminance) **/
void      utiImage3DMinMax2D(utiImage3D  *ep, int iz, unsigned int minmaxp[2]);
void      utiImage3DAdd2DMinMax(utiImage3D *e3p, utiImage2D *e2p);
void      utiImage3DMinMax(utiImage3D *ep);
#endif
/******************************************************************************/
/******************************************************************************/
