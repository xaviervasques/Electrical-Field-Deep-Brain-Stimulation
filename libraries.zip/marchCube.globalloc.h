#ifndef  DEF_MARCHCUBE_GLOBALLOC_H
#define  DEF_MARCHCUBE_GLOBALLOC_H

#include  "marchCube.h"

double    elemCubeValues[8];
double    elemCubePositions[8][3];

Triangle  Triangles[5];

#endif
/******************************************************************************/
/******************************************************************************/
