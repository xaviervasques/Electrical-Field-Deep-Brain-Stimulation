/*  libc/recipe2double/recipe.amoeba.h                                        */
/*  Last Revised : G.M.               20030522                                */

/** VECTOR and MATRIX INDICES FROM 0 to DIM-1                                **/
/** VECTOR and MATRIX : DOUBLE version                                       **/

#ifndef  DEF_AMOEBA_H
#define  DEF_AMOEBA_H

void      amoeba(double **p, double y[], int ndim, double ftol,
                                  double (*funk)(double []), int *nfunk, int nfunkx);

#endif
/******************************************************************************/
/******************************************************************************/
