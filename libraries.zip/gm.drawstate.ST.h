/*  URMAE/orientHaut/linear4.GL.V1/gm.drawstate.ST.h                          */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20030519                                */

#ifndef  DEF_GM_DRAWSTATE_ST_H
#define  DEF_GM_DRAWSTATE_ST_H

#include  "utiVecChr.h"
#include  "utiCurve.set.h"

void      gmDrawStateSTInit();

chrVec   *gmDrawStateSTGetpsiRotV();
double    gmDrawStateSTGetpsiRot();
void      gmDrawStateSTSetpsiRot(double psiDegree);
chrVec   *gmDrawStateSTGetzhV();
double    gmDrawStateSTGetzh();
void      gmDrawStateSTSetzh(double zh);

void      gmDrawStateSTSetdefLimRho();
void      gmDrawStateSTSetdefLimZ();
void      gmDrawStateSTSetdefLimX();
void      gmDrawStateSTSetdefLimY();
void      gmDrawStateSTSetLimfromRhoZScaleRatio(double hwscaleratio);

double   *gmDrawStateSTGetLimRho();
double   *gmDrawStateSTGetLimZ();
double   *gmDrawStateSTGetLimX();
double   *gmDrawStateSTGetLimY();

cSetVec  *gmDrawStateSTGetRZallCSetp();
cSetVec  *gmDrawStateSTGetXYallCSetp();

void      gmDrawStateSTSetRZallCSet();
void      gmDrawStateSTSetXYallCSet();

void      gmDrawStateSTSetPallidusCSet();
void      gmDrawStateSTPSprint(FILE *psFilep);

#endif
/******************************************************************************/
/******************************************************************************/
