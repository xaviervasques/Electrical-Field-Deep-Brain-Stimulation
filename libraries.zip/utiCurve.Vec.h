/*   ../libmy/utiCurve.Vec.h                                                  */
/*   Mennessier Gerard                  20020902                              */
/*   Last revised M.G.                  20020904                              */

#ifndef  DEF_UTICURVE_VEC_H
#define  DEF_UTICURVE_VEC_H

#include  <stddef.h>
#include  <stdlib.h>
#include  "utiCurve.GC.h"

/** malloc,realloc,free  are defined in  stdlib.h (ANSI)                          **/
/** on old SunOS 4, they are  char*  valued (instead of  void*)                   **/
/** malloc.h  is necessary only if need access to  mallinfo  structure ...        **/
/** ...ChkRealloc(... *p,size_t *nzp,size_t neednz,size_t incrnz, char *prognamp) **/

/******************************************************************************/
/**       myCurveVec structure                                               **/
/******************************************************************************/
typedef struct myCurveVec
{ size_t        z;
  size_t        x;
  void         *p;
  curveGC      *gcp;         /** pointer to associated GC **/
} myCurveVec, *myCurveVecp;

extern myCurveVec  *myCurveVecAlloc(size_t, char *);
extern myCurveVec  *myCurveVecChkRealloc(myCurveVec *, size_t *, size_t, size_t,
                                                                             char *);

#endif
/******************************************************************************/
/******************************************************************************/

