/*  URMAE/orientHaut/linear4.GL.V1/gl.linear4.globalloc.h                     */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20010808                                */

#ifndef  DEF_GL_LINEAR4_GLOBALLOC_H
#define  DEF_GL_LINEAR4_GLOBALLOC_H

#include  <GL/glut.h>
#include  "gl.linear4.def.h"

/*
0  ConsoleRoot
1  sub 0     00     Patient
2  sub 1    000     Menu OK/CANCEL changement patient
3  sub 0     01     Caracteristiques electriques
4  sub 3    010     Pin modes
5  sub 3    011     Voltage
6  sub 3    012     Impedance
7  sub 3    013     Menu OK/CANCEL 
*/

                                               /** size of accessible Full Sreen **/
int       winrw,  winrh;
int       fullw = 1024,  fullh = 900;
GLfloat   strokeRomanSizeHF = 100.0,  strokeRomanSizeWF = 70.0;

                                                             /** index of windows **/
int       winp[MY_GL_WIN_NUMBER];
                 /** index of menus,  menu -> index of window which it belongs to **/
int       menup[MY_GL_MENU_NUMBER],  menu2winp[MY_GL_MENU_NUMBER];
                                                      /** current size of windows **/
int       winwp[MY_GL_WIN_NUMBER],  winhp[MY_GL_WIN_NUMBER];

#endif
/******************************************************************************/
/******************************************************************************/
