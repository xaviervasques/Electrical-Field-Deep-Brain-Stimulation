/*  bio_phys/URMAE/numerical/linear4/pot.linear4.h                            */
/*  Mennessier Gerard                 20000414                                */
/*  Last Revised : G.M.               20011228                                */

#ifndef   DEF_POT_LINEAR4_H
#define   DEF_POT_LINEAR4_H

#include  "utistdIO.h"

#include  "gridZ.linear4.h"
#include  "gridR.linear4.h"

typedef struct gmPotStruct
{ gmGridR  *gridRp;
  gmGridZ  *gridZp;
  void     *varPotp;
  double   *vp;
  double  **vpp;
  size_t    vpx;
  size_t    vppx;
} gmPot, *gmPotp;

void      gmPotPAllocZero(gmPot *p, gmGridR *gridRp, gmGridZ *gridZp);
void      gmPotPrint(FILE *bufOut, gmPot *p);
void      gmPotPrintMath(FILE *bufOut, gmPot *p);
double    gmPotFunc(double rho, double z, gmPot *p);
double    gmPotFunc2(double rho, double z, gmPot *p);
double    gmPotInterpol(double rho, double z, double **vpp,
                                                   gmGridR *gridrp, gmGridZ *gridzp);

#endif
/******************************************************************************/
/******************************************************************************/
