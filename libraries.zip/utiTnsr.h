/*  ../libmy/utiTnsr.h                                                        */
/*  Mennessier Gerard                   20010611                              */
/*       revised : M.G.                 20030205                              */
/*       revised : M.G.                 20050706                              */
/*  Last revised : M.G.                 20051124                              */

                                                      /** Tensors, dim =2, double **/
#ifndef  DEF_UTITNSR_H
#define  DEF_UTITNSR_H

#include  <stddef.h>
#include  "utistdIO.h"
/******************************************************************************/
/*  tnsr2dbl.pp[i < ev1x] [j < ev2x]                                          */
/*  tp = tnsr2dbl.pp[i] , i=0 - (ev1x-1)                                      */
/*     t  = tp[j]       , j=0 - (ev2x-1)                                      */
/*  or t = tnsr2dbl.pp[i][j]                                                  */
/*  or t = tnsr2dbl.p[i*ev2z + j]                                             */
/******************************************************************************/
typedef struct tnsr2dbl
{ size_t        pz;
  size_t        ev1z;
  size_t        ev1x;
  size_t        ev2z;
  size_t        ev2x;
  double       *p;
  double      **pp;
} tnsr2dbl, *tnsr2dblp;

extern    tnsr2dbl *tnsr2dblAlloc(size_t nz, char *prognamp);
extern    void      tnsr2dblPAlloc(tnsr2dbl *p, size_t ev1z, size_t ev2z);
extern    void      tnsr2dblPRealloc(tnsr2dbl *tp, size_t needev1z, size_t needev2z);
extern    void      tnsr2dblPrint(FILE  *bufp, tnsr2dbl *p);
extern    void      tnsr2dblPPrint(FILE  *bufp, tnsr2dbl *p);
extern    void      tnsr2dblCopy (tnsr2dbl *pf, tnsr2dbl *pi);
extern    void      tnsr2dblAdd  (tnsr2dbl *pi, tnsr2dbl *p);
extern    void      tnsr2dblShift(tnsr2dbl *pi, double d);
extern    void      tnsr2dblShiftE1a(tnsr2dbl *pi, double *shiftp);
extern    void      tnsr2dblShiftE1b(tnsr2dbl *pi, double *shiftp);
extern    void      tnsr2dblSumE1a(tnsr2dbl *pi, double *sump);
extern    void      tnsr2dblSumE1b(tnsr2dbl *pi, double *sump);
extern    void      tnsr2dblMinMaxE1b(tnsr2dbl *pi, double *minp, double *maxp);
/******************************************************************************/
typedef struct tnsr2flt
{ size_t        pz;
  size_t        ev1z;
  size_t        ev1x;
  size_t        ev2z;
  size_t        ev2x;
  float        *p;
  float       **pp;
} tnsr2flt, *tnsr2fltp;

extern    tnsr2flt *tnsr2fltAlloc(size_t nz, char *prognamp);
extern    void      tnsr2fltPAlloc(tnsr2flt *p, size_t ev1z, size_t ev2z);
extern    void      tnsr2fltPrint(FILE  *bufp, tnsr2flt *p);
extern    void      tnsr2fltPPrint(FILE  *bufp, tnsr2flt *p);

/******************************************************************************/
typedef struct tnsr2int
{ size_t        pz;
  size_t        ev1z;
  size_t        ev1x;
  size_t        ev2z;
  size_t        ev2x;
  int          *p;
  int         **pp;
} tnsr2int, *tnsr2intp;

extern    tnsr2int *tnsr2intAlloc(size_t nz, char *prognamp);
extern    void      tnsr2intPAlloc(tnsr2int *p, size_t ev1z, size_t ev2z);
extern    void      tnsr2intPrint(FILE  *bufp, tnsr2int *p);
extern    void      tnsr2intPPrint(FILE  *bufp, tnsr2int *p);

#endif
/******************************************************************************/
/******************************************************************************/
