/*  essai/C/utiCurve.circle.h                                                 */
/*  Mennessier Gerard                   20010502                              */
/*  Last revised M.G.                   20030625                              */
/*                                                                            */

#ifndef  DEF_UTICURVE_CIRCLE_H
#define  DEF_UTICURVE_CIRCLE_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiAlloc.h"
#include  "utiMath.type.def.h"
#include  "utiCurve.GC.h"
#include  "utiCurve.Vec.h"

/******************************************************************************/
/*  cCircle : arc of a circle                                                 */
/******************************************************************************/
typedef struct cCircle                                             /** circle arc **/
{ double        xp[2];       /** x,y coord of center **/
  double        r;           /** radius **/
  double        anglp[2];    /** first and last angles, in DEGREES, math oriented **/
  curveGC      *gcp;         /** pointer to associated GC **/
  myBOOL        closed;      /** if TRUE, close the circle **/
} cCircle, *cCirclep;

cCircle  *cCircleAlloc(size_t  nz,char *prognamp);
cCircle  *cCircleChkRealloc(cCircle *p,size_t  *nzp,size_t neednz,size_t incrnz,
                                                                     char *prognamp);
void      cCirclePrint(FILE *bufp, cCircle *p);
void      cCircleZero(cCircle *p);
void      cCircleSet(cCircle *p, double *xp, double r, double *anglp);
void      cCircleCopypp(cCircle *pf, cCircle *pi);
void      cCircleCopyp(cCircle *pf, cCircle cc);

/******************************************************************************/
/*  cCircleVec                                                                */
/******************************************************************************/
typedef struct cCircleVec
{ size_t        z;
  size_t        x;
  cCircle      *p;
  curveGC      *gcp;         /** pointer to associated GC **/
} cCircleVec, *cCircleVecp;

#define   cCircleVecAlloc(nz,prognamp)   (cCircleVec *)myCurveVecAlloc((nz),prognamp)
#define   cCircleVecChkRealloc(p,nzp,needz,inz,pronamp)              \
                          (cCircleVec *)myCurveVecChkRealloc(p,nzp,needz,inz,pronamp)
void      cCirclePVecAlloc(cCircleVec *vecp,size_t  nz);
void      cCirclePVecRealloc(cCircleVec *vecp,size_t neednz,size_t incrnz);
void      cCirclePVecFree(cCircleVec *vecp);
void      cCircleVecFree(cCircleVec *vecp);
void      cCircleVecPrint(FILE  *bufp, cCircleVec *vecp);
void      cCircleVecInc1(cCircleVec *vecp, cCircle cc);
void      cCircleVecInc1p(cCircleVec *vecp, cCircle *ccp);
void      cCircleVecInc1Data(cCircleVec *vecp, double *xp, double r, double *anglp);

#endif
/******************************************************************************/
/******************************************************************************/
