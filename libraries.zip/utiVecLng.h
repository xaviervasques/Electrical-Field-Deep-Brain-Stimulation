/*  ../libmy/utiVecLng.h                                                      */
/*  Mennessier Gerard                   940822                                */
/*  Last revised              M.G.      970505                                */

#ifndef  DEF_UTIVECLNG_H
#define  DEF_UTIVECLNG_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiAlloc.h"

typedef struct lngVec
{ size_t        z;
  size_t        x;
  long          *p;
} lngVec, *lngVecp;

#define  lngVecAlloc(nz,prognamp)            (lngVec *)myVecAlloc((nz),prognamp)
#define  lngVecChkRealloc(p,nzp,needz,inz,pronamp)              \
                              (lngVec *)myVecChkRealloc(p,nzp,needz,inz,pronamp)
/* extern    lngVec   *lngVecAlloc   (size_t nz, char *prognamp); */
extern    void      lngPVecAlloc  (lngVec *vecp,size_t  nz);
extern    void      lngPVecRealloc(lngVec *vecp,size_t neednz,size_t incrnz);
extern    void      lngPVecFree   (lngVec *vecp);
extern    void      lngVecFree    (lngVec *vecp);
extern    void      lngVecPrint   (FILE  *bufp,lngVec *vecp);
extern    void      lngVecInc1    (lngVec *vecp,long y);
extern    void      lngVecIncN    (lngVec *vecp,long *yp,size_t n);

#endif
/******************************************************************************/
/******************************************************************************/
