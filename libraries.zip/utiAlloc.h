/*   ../libmy/utiAlloc.h                                                      */
/*   Mennessier Gerard                  19940624                              */
/*   Last revised M.G.                  20030926                              */

#ifndef  DEF_UTIALLOC_H
#define  DEF_UTIALLOC_H

#include  <stddef.h>
#include  <stdlib.h>
/*
extern    void     *malloc(size_t); 
extern    void     *realloc(void *, size_t);
extern    void      free(void *);
*/

#define   pdfAlloc       ptrdfAlloc
#define   pdfChkRealloc  ptrdfChkRealloc

/** malloc,realloc,free  are defined in  stdlib.h (ANSI)                          **/
/** on old SunOS 4, they are  char*  valued (instead of  void*)                   **/
/** malloc.h  is necessary only if need access to  mallinfo  structure ...        **/
/** ...ChkRealloc(... *p,size_t *nzp,size_t neednz,size_t incrnz, char *prognamp) **/

/******************************************************************************/
extern    char     *chrAlloc(size_t  nz,char *prognamp);
extern    char     *chrChkRealloc(char *, size_t *, size_t, size_t, char *);
extern    double   *dblAlloc(size_t, char *);
extern    double   *dblChkRealloc(double *, size_t *, size_t, size_t, char *);
extern    float    *fltAlloc(size_t nz, char *progcallp);
extern    float    *fltChkRealloc(float *, size_t *, size_t, size_t, char *);
extern    int      *intAlloc(size_t  nz,char *prognamp);
extern    int      *intChkRealloc(int *, size_t *, size_t, size_t, char *);
extern    unsigned int  *uintAlloc(size_t  nz,char *prognamp);
extern    unsigned int  *uintChkRealloc(unsigned int *, size_t *, size_t, size_t, char *);
extern    long     *lngAlloc(size_t, char *);
extern    long     *lngChkRealloc(long *, size_t *, size_t, size_t, char *);
extern    void     *ptrAlloc(size_t, char *);
extern    void     *ptrChkRealloc(void *, size_t *, size_t, size_t, char *);
extern    ptrdiff_t   *ptrdfAlloc(size_t, char *);
extern    ptrdiff_t   *ptrdfChkRealloc(ptrdiff_t *, size_t *, size_t, size_t,char *);  
/******************************************************************************/

                    /**************************************/
                    /**         myVec structure          **/
                    /**************************************/
/******************************************************************************/
typedef struct myVec
{ size_t        z;
  size_t        x;
  void         *p;
} myVec, *myVecp;

extern    myVec    *myVecAlloc(size_t, char *);
extern    myVec    *myVecChkRealloc(myVec *, size_t *, size_t, size_t, char *);
/******************************************************************************/

                    /**************************************/
                    /**         myBook structure         **/
                    /**************************************/
/******************************************************************************/
typedef struct myBook
{ size_t        bz;
  size_t        bx;
  void         *bp;
  size_t        iz;
  size_t        ix;
  ptrdiff_t    *ip;
} myBook, *myBookp;

extern    myBook   *myBookAlloc(size_t, char *);
extern    myBook   *myBookChkRealloc(myBook *, size_t *, size_t, size_t, char *);

#endif
/******************************************************************************/
/******************************************************************************/

