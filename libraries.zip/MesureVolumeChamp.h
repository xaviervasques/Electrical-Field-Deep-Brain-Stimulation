Ligne de Champs; Volume complet;
 
 0.200000, 16.080532
