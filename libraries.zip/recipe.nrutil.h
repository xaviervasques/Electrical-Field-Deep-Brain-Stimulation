/*  libc/recipe2double/recipe.nrutil.h                                        */

#ifndef  _RECIPE_NR_UTILS_H_
#define  _RECIPE_NR_UTILS_H_

/* static    double dmaxarg1, dmaxarg2; */
#define   DMAX(a,b) ( dmaxarg1 = (a), dmaxarg2 = (b), \
                    (dmaxarg1) > (dmaxarg2) ? (dmaxarg1) : (dmaxarg2) \
                  )

/* static    double dminarg1, dminarg2; */
#define   DMIN(a,b) ( dminarg1 = (a), dminarg2 = (b), \
                    (dminarg1) < (dminarg2) ? (dminarg1) : (dminarg2) \
                  )

                        /** #include <math.h>  double fabs(double x); is STANDARD **/
                                                     /** SIGN(a,b) = sign(b) |a|  **/
#define   SIGN(a,b) ( (b) >= 0.0 ? fabs(a) : -fabs(a) )


#endif /* _RECIPE_NR_UTILS_H_ */
