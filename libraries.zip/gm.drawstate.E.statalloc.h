/*  URMAE/orientHaut/linear4.GL.V1/gm.drawstate.E.statalloc.h                 */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20020418                                */

#ifndef  DEF_GM_DRAWSTATE_E_STATALLOC_H
#define  DEF_GM_DRAWSTATE_E_STATALLOC_H

#include  "utiVecChr.h"
#include  "utiCurve.level.h"
#include  "utiCurve.set.h"
                              /** GEOMETRIC PARAMETERS **/
                              /** ELECTRODE Frame **/
                                                                 /** psi rotation **/
static    chrVec    stateEpsiRotV = {0,0,NULL};      /** (in degree): char string **/
static    double    stateEpsiRotDeg,  stateEpsiRotRad;  
                                                              /** section z value **/
static    chrVec    stateEzhV = {0,0,NULL};                       /** char string **/
static    double    stateEzh;
                                       /** limits for effective drawing in window **/
static    double    stateELimRho[2] = {-4.05, +4.05},
                    stateELimZ[2] = {-6.10, +6.10},
                    stateELimX[2] = {-4.05, +4.05},
                    stateELimY[2] = {-4.05, +4.05}; 

                              /** CURVES SETS **/
                              /** ELECTRODE Frame **/
static    char     *stateETitlesp[6];

static    cSetVec   ERZeltrdAxisCSetv = {0,0,NULL},
                    ERZtitleCSetv = {0,0,NULL},
                    ERZlevelCSetv = {0,0,NULL};
static    cSetVec   ERZallCSetv = {0,0,NULL};

static    cSetVec   EXYeltrdAxisCSetv = {0,0,NULL},
                    EXYtitleCSetv = {0,0,NULL},
                    EXYlevelCSetv = {0,0,NULL};
static    cSetVec   EXYallCSetv = {0,0,NULL};

#endif
/******************************************************************************/
/******************************************************************************/
