/*  libc/libmy/utiMath.constant.def.h                                         */
/*  Mennessier Gerard                 20000414                                */
/*  Last Revised : G.M.               20030624                                */

#ifndef  DEF_UTIMATH_CONSTANT_DEF_H
#define  DEF_UTIMATH_CONSTANT_DEF_H 

#define   myPI         3.14159265358979323846
#define   myDEG2RAD   (myPI /180.0)
#define   myRAD2DEG   (180./myPI)

#define   myE          2.71828182845904523536

#endif
/******************************************************************************/
/******************************************************************************/
