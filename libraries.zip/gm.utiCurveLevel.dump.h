/*  URMAE/orientHaut/linear4.GL.V6/gm.utiCurveLevel.dump.h                    */
/*  Mennessier Gerard                 20060213                                */
/*  Last Revised : G.M.               20060213                                */

#ifndef  DEF_GM_UTICURVE_LEVEL_DUMP_H
#define  DEF_GM_UTICURVE_LEVEL_DUMP_H

#include  <stddef.h>

#include  "utistdIO.h"
#include  "utiCurve.level.h"

void      gmLevelDump(char *filenamp);
void      utiCurveLevelDump(FILE *streamp, lcZrange *lczrp, lcSegVec *lcsegvecp);

#endif
/******************************************************************************/
/******************************************************************************/
