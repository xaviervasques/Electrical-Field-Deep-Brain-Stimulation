/*  essai/C/utiCurve.seg.h                                                    */
/*  Mennessier Gerard                   20010502                              */
/*  Last revised M.G.                   20020904                              */
/*                                                                            */

#ifndef  DEF_UTICURVE_SEG_H
#define  DEF_UTICURVE_SEG_H

#include  <stddef.h>
#include  "utistdIO.h"
#include  "utiAlloc.h"
#include  "utiCurve.GC.h"

/******************************************************************************/
/*  cSeg : segment                                                            */
/******************************************************************************/
typedef struct curveSeg
{ double   x[2];    /** x coord of 2 extremities **/
  double   y[2];    /** y coord of 2 extremities **/
} cSeg, *cSegp;

cSeg     *cSegAlloc(size_t  nz,char *prognamp);
cSeg     *cSegChkRealloc(cSeg *p,size_t  *nzp,size_t neednz,size_t incrnz,
                                                                     char *prognamp);
void      cSegPrint(FILE *bufp,cSeg *p);
void      cSegArrayPrint(FILE *bufp,cSeg *p,size_t n);
void      cSegZero(cSeg *p);
void      cSegCpy1p(cSeg *sfp,cSeg *sip);

/******************************************************************************/
/*  cSegVec                                                                   */
/******************************************************************************/
typedef struct cSegVec
{ size_t        z;
  size_t        x;
  cSeg         *p;
  curveGC      *gcp;         /** pointer to associated GC **/
} cSegVec, *cSegVecp;

#define   cSegVecAlloc(nz,prognamp)         (cSegVec *)myCurveVecAlloc((nz),prognamp)
#define   cSegVecChkRealloc(p,nzp,needz,inz,pronamp)              \
                             (cSegVec *)myCurveVecChkRealloc(p,nzp,needz,inz,pronamp)
void      cSegPVecAlloc(cSegVec *vecp,size_t  nz);
void      cSegPVecRealloc(cSegVec *vecp,size_t neednz,size_t incrnz);
void      cSegPVecFree(cSegVec *vecp);
void      cSegVecFree(cSegVec *vecp);
void      cSegVecPrint(FILE  *bufp, cSegVec *vecp);
void      cSegVecInc1(cSegVec *vecp,cSeg s);
void      cSegVecInc1p(cSegVec *vecp,cSeg *sp);
void      cSegVecInc1PointData(cSegVec *vecp,double *p1p, double *p2p);
void      cSegVecInc1CoorData(cSegVec *vecp,double x0, double y0,
                                                               double x1, double y1);
void      cSegVecInc1CoorPData(cSegVec *vecp,double *xp, double *yp);

#endif
/******************************************************************************/
/******************************************************************************/
