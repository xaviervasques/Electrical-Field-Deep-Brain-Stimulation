/*  URMAE/numerical/linear4/gridRZ.linear4.h                                  */
/*  Mennessier Gerard                 20000414                                */
/*  Last Revised : G.M.               20010611                                */

#ifndef  DEF_GRIDRZ_LINEAR4_H
#define  DEF_GRIDRZ_LINEAR4_H

#include  <stddef.h>
#include  "utistdIO.h"

#include  "gridZ.linear4.h"
#include  "gridR.linear4.h"

int       gmGridRZGeoinit(FILE *bufOut, gmGridR *Rp, gmGridZ *Zp);

#endif
/******************************************************************************/
/******************************************************************************/
