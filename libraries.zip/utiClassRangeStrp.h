/*  ../libmy/utiClassRangeStrp.h                                              */
/*  Mennessier Gerard                   940810                                */
/*  Last Revised              M.G.      970421                                */

#ifndef   UTICLASSRANGESTRP_H
#define   UTICLASSRANGESTRP_H

#include  <stddef.h>

void      ranindStrp(unsigned char **xp,int *indp,size_t nz);
int       classStrp(int *indexp,char *newsp,char  *spp[],size_t nx);

#endif
/******************************************************************************/
