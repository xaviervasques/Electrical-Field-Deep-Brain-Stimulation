/*  bio_phys/URMAE/numerical/linearGL4/gl.linear4.00.globalloc.h              */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20030509                                */

#ifndef  DEF_GL_LINEAR4_00_GLOBALLOC_H
#define  DEF_GL_LINEAR4_00_GLOBALLOC_H

#include  <GL/glut.h>
#include  "utiVecChr.h"

GLfloat   win00ew, win00eh,
          win000ew, win000eh, win001ew, win001eh;

GLfloat   rs00w  = 1.0, rs00h  = 0.20,
          rs000w = 0.9, rs000h = 0.6666, rs001w = 0.1, rs001h = 0.6666;
GLfloat   p00w  = 0.0, p00h  = 0.0;
GLfloat   p000w = 0.0, p001w = 0.9;
GLfloat   p000h = 0.3, p001h = 0.3;

chrVec    patientNameV = {0,0,NULL}, 
          newPatientNameV = {0,0,NULL};
GLfloat   patientNameWidthF = 1200.0;

#endif
/******************************************************************************/
/******************************************************************************/
