/*  URMAE/orientHaut/linear4.GL.V1/gl.linear4.glob.h                          */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20010808                                */

#ifndef  DEF_GL_LINEAR4_GLOB_H
#define  DEF_GL_LINEAR4_GLOB_H

#include  <GL/glut.h>
#include  "gl.linear4.def.h"

extern    int       winrw,  winrh;
extern    int       fullw,  fullh;
extern    GLfloat   strokeRomanSizeHF,  strokeRomanSizeWF;

extern    int       winp[];
extern    int       menup[],  menu2winp[];
extern    int       winwp[],  winhp[];

#endif
/******************************************************************************/
/******************************************************************************/
