#ifndef DEF_FIELDPOINT_H 
#define DEF_FIELDPOINT_H 

extern double Champs[][3];

#endif
