#ifndef  DEF_DATAPOINTS_GLOBALLOC_H
#define  DEF_DATAPOINTS_GLOBALLOC_H

#include  <stddef.h>
#include  "utiVecDbl.h"

/*Donn�es � fournir*/
/******************************************************************************/
/******************************************************************************/
/** Position centre electrode  dans repere stereo **/
double         targetp[3] = {82.6,91.8,94.9};

/** Angles d'Euler de electrode dans repere stereo: A et B **/
double         phiEl = 90-89.7, thetaEl = 90-89.5;
/** GPi droit = 1 ou GPi gauche = 0 **/
int Gpiside = 1;

size_t         NPTS;
dblVec         ptsInitVec = {0, 0, NULL};
dblVec         ptsCentresVec = {0, 0, NULL};
dblVec         weightVec = {0, 0, NULL};

/** translation initiale de recentrage  vers electrode et pallidus **/
double         cg[3];
double         ptsInitMinp[3],  ptsInitMaxp[3];
double         ptsInitMinp[3],  ptsInitMaxp[3];
double        *ptsCentresp;
double         ptsCentresMinp[3],  ptsCentresMaxp[3];
double         ptsCentresMin,      ptsCentresMax;
double         typicalSize;

#endif
/******************************************************************************/
/******************************************************************************/
