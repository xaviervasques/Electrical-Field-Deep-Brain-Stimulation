/*  URMAE/orientHaut/linear4.GL.V1/pallidus.geom.h                            */
/*  Mennessier Gerard                 20000414                                */
/*  Last Revised : G.M.               20020410                                */

#ifndef   DEF_PALLIDUS_GEOM_H
#define   DEF_PALLIDUS_GEOM_H

void      pallidusInitGeom(char *pallidusFileNamep);
size_t    pallidusGetData(char *pallidusDataFileNamp);
void      pallidusSsortPosData();
                                              /** function of Electrode data only **/
void      pallidusGetAffineRotation();
void      pallidusS2EAffineRotate1pt(double *exfp, double *sxip);
void      pallidusST2ERotate1pt(double *exfp, double *sxip);
void      pallidusE2SAffineRotate1pt(double *exfp, double *sxip);
void      pallidusE2STRotate1pt(double *exfp, double *sxip);
void      pallidusS2ERotateCheck();
void      pallidusE2SRotateCheck();
                                             /** function of Pallidus data itself **/
void      pallidusSsortedData2STBound();
void      pallidusSTBoundPsiRotate(double psi);
void      pallidusST2EBound();
void      pallidusS2EDataAffineRotate();
void      pallidusEBoundPsiRotate(double psi);
/* void      pallidusEQuadr(); */

void      pallidusCircPerm(int *ip, int ix, int i0);

#endif
/******************************************************************************/
/******************************************************************************/
