/*  URMAE/orientHaut/linear4.GL.V1/gm.draw.E.h                                */
/*  Mennessier Gerard                 20000414                                */
/*  Last Revised : G.M.               20020410                                */

#ifndef  DEF_GM_DRAW_E_H
#define  DEF_GM_DRAW_E_H

#include  "utistdIO.h"
#include  "utiCurve.level.h"
#include  "utiCurve.seg.h"
#include  "utiCurve.set.h"
#include  "utiCurve.string.h"
#include  "gridZ.linear4.h"
#include  "gridR.linear4.h"
#include  "cylPot.linear4.h"
#include  "eltrdPot.linear4.h"

void      gmDrawEGetRZeltrdAxis(cSetVec *csetvp,
                                             gmGridZ *gridZp_mm, gmGridR *gridRp_mm);
cSegVec  *gmDrawEGetRZtraceXYsection(double zh);

void      gmDrawEGetXYeltrdAxis(cSetVec *csetvp,
                                  gmGridZ *gridZp_mm, gmGridR *gridRp_mm, double zh);

void      gmDrawEComputeRZLevels(cSetVec *csetvp, gmGridZ *gridZp_mm,
                                  gmGridR *gridRp_mm, double **fpp, lcZrange *lczrp);
void      gmDrawEComputeXYLevels(cSetVec *csetvp, gmGridZ *gridZp_mm, 
                       gmGridR *gridRp_mm, double **fpp, lcZrange *lczrp, double zh);
cStrVec  *gmDrawEGetRZCStrTitle(char **titlespp, int vei, char **Etitlespp);
cStrVec  *gmDrawEGetXYCStrTitle(char **titlespp, int vei, char **Etitlespp);
cStrVec  *gmDrawEGetCStrPinIndices();

#endif
/******************************************************************************/
/******************************************************************************/
