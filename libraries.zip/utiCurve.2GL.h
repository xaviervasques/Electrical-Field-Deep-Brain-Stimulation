/*  essai/C/utiCurve.2GL.h                                                    */
/*  Mennessier Gerard                   20010629                              */
/*  Last revised M.G.                   20030626                              */
/*                                                                            */

#ifndef  DEF_UTICURVE_2GL_H
#define  DEF_UTICURVE_2GL_H

#include  <stddef.h>

#include  "utistdIO.h"

#include  "utiCurve.circle.h"
#include  "utiCurve.ellipse.h"
#include  "utiCurve.level.h"
#include  "utiCurve.poly.h"
#include  "utiCurve.seg.h"
#include  "utiCurve.string.h"
#include  "utiCurve.set.h"

/******************************************************************************/
void      GLgraphInit(int win, double xnx[2], double ynx[2]);
void      GLgraphEnd (int win);

void      GLgraphSet  (int win, cSetVec  *setvecp);
void      GLgraphSetGC(curveGC *gcp);

void      GLgraphPoly   (int win, cPoly    *p);
void      GLgraphPolyV  (int win, cPolyVec *vecp);
void      GLgraphSegV   (int win, cSegVec  *segvecp);
void      GLgraphLcSeg  (int win, lcSegVec *segvecp);
void      GLgraphStr    (int win, cStrVec  *strvecp);
void      GLgraphCircle (int win, cCircle *p, curveGC *vgcp);
void      GLgraphCircleV(int win, cCircleVec *vecp);
void      GLgraphEllipse(int win, cEllipse *p, curveGC *vgcp);
void      GLgraphEllipseV(int win, cEllipseVec *vecp);

#endif
/******************************************************************************/
/******************************************************************************/
