/*  URMAE/numerical/linear4/f2gradf.h                                         */
/*  Mennessier Gerard                 20010527                                */
/*  Last Revised : G.M.               20010527                                */

#ifndef  DEF_F2GRADF_H
#define  DEF_F2GRADF_H

#include  <stddef.h>

void      getGeo2DGradNorm(double *xp, size_t xx, double *yp, size_t yx,
                      int *iyGeo2ixfp, int *iyGeo2ixlp, double **fpp, double **gNpp);

#endif
/******************************************************************************/
/******************************************************************************/
