/*  libc/recipe2double/recipe.mnbrak.h                                        */
/** VECTOR and MATRIX : DOUBLE version                                       **/

#ifndef  DEF_MNBRAK_H
#define  DEF_MNBRAK_H

void      mnbrak(double *axp, double *bxp, double *cxp,
                      double *fap, double *fbp, double *fcp, double (*func)(double));

#endif
/******************************************************************************/
/******************************************************************************/
