/*  URMAE/orientHaut/linear4.GL.V1/gm.drawstate.E.h                           */
/*  Mennessier Gerard                 20010613                                */
/*  Last Revised : G.M.               20020418                                */

#ifndef  DEF_GM_DRAWSTATE_E_H
#define  DEF_GM_DRAWSTATE_E_H

#include  "utiVecChr.h"
#include  "utiCurve.set.h"

void      gmDrawStateEInit();

chrVec   *gmDrawStateEGetpsiRot();
void      gmDrawStateESetpsiRot(double psiDegree);
chrVec   *gmDrawStateEGetzh();
void      gmDrawStateESetzh(double zh);

void      gmDrawStateESetdefLimRho();
void      gmDrawStateESetdefLimZ();
void      gmDrawStateESetdefLimX();
void      gmDrawStateESetdefLimY();
void      gmDrawStateESetLimfromRhoZScaleRatio(double hwscaleratio);

double   *gmDrawStateEGetLimRho();
double   *gmDrawStateEGetLimZ();
double   *gmDrawStateEGetLimX();
double   *gmDrawStateEGetLimY();

cSetVec  *gmDrawStateEGetRZlevelCSetp();
cSetVec  *gmDrawStateEGetRZallCSetp();
cSetVec  *gmDrawStateEGetXYallCSetp();

void      gmDrawStateESetRZallCSet();
void      gmDrawStateESetXYallCSet();

void      gmDrawStateESetPallidusCSet();
void      gmDrawStateEPSprint(FILE *psFilep);

#endif
/******************************************************************************/
/******************************************************************************/
